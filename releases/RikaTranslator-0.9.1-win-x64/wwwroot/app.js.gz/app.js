'use strict';

const icons = {
  library:
    '<rect x="3" y="4" width="7" height="7" rx="2"/><rect x="14" y="4" width="7" height="7" rx="2"/><rect x="3" y="15" width="7" height="6" rx="2"/><rect x="14" y="15" width="7" height="6" rx="2"/>',
  game: '<path d="M7 7h10a4 4 0 0 1 4 3l1 7a2.5 2.5 0 0 1-4.4 1.8L15 16H9l-2.6 2.8A2.5 2.5 0 0 1 2 17l1-7a4 4 0 0 1 4-3Z"/><path d="M6 10v5m-2.5-2.5h5"/><circle cx="16.5" cy="11.5" r=".6"/><circle cx="19" cy="14" r=".6"/>',
  ai: '<path d="m12 3 2.3 6.7L21 12l-6.7 2.3L12 21l-2.3-6.7L3 12l6.7-2.3Z"/><path d="m20 2 .6 1.4L22 4l-1.4.6L20 6l-.6-1.4L18 4l1.4-.6Z"/>',
  translate: '<path d="M3 5h12M9 3v2m4 0c-1 6-4 9-9 12m0-10c1 4 4 7 8 9m1 5 4-11 4 11m-6.8-4h5.6"/>',
  book: '<path d="M12 5v16m0-16C9 3 5 3 2 4v15c3-1 7-1 10 2m0-16c3-2 7-2 10-1v15c-3-1-7-1-10 2"/>',
  logs: '<path d="M14 2H5a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V9Z"/><path d="M14 2v7h7M7 13h10M7 17h7"/>',
  settings: '<path d="m9 3-1 3-3 1-2 4 2 2v4l4 2 3-1 3 1 4-2v-4l2-2-2-4-3-1-1-3Z"/><circle cx="12" cy="12" r="3"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  list: '<path d="M8 5h13M8 12h13M8 19h13M3 5h.01M3 12h.01M3 19h.01"/>',
  play: '<path d="m8 4 13 8-13 8Z"/>',
  pause: '<path d="M8 4v16M16 4v16"/>',
  arrow: '<path d="m9 5 7 7-7 7"/>',
  back: '<path d="m14 5-7 7 7 7"/>',
  close: '<path d="m6 6 12 12M6 18 18 6"/>',
  check: '<path d="m4 12 5 5L20 6"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
  warning: '<path d="m10 4-8 14a2 2 0 0 0 2 3h16a2 2 0 0 0 2-3L14 4a2.3 2.3 0 0 0-4 0Z"/><path d="M12 9v4m0 4h.01"/>',
  shield: '<path d="m12 2 9 4v6c0 5-9 10-9 10S3 17 3 12V6Z"/><path d="m8 12 3 3 5-6"/>',
  folder: '<path d="M3 7V5a2 2 0 0 1 2-2h5l3 3h6a2 2 0 0 1 2 2v1M3 7h18a1 1 0 0 1 1 1l-2 11H4L2 8a1 1 0 0 1 1-1Z"/>',
  refresh: '<path d="M21 6v5h-5M3 18v-5h5M5 7a8 8 0 0 1 13-2l3 3M3 16l3 3a8 8 0 0 0 13-2"/>',
  download: '<path d="M12 3v12m-5-5 5 5 5-5M3 16v4h18v-4"/>',
  upload: '<path d="M12 16V4m-5 5 5-5 5 5M3 16v4h18v-4"/>',
  edit: '<path d="m16 3 5 5-12 12-6 1 1-6ZM13 6l5 5"/>',
  trash: '<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>',
  moon: '<path d="M21 13a9 9 0 0 1-10-10A9 9 0 1 0 21 13Z"/>',
  monitor: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M12 17v4m-5 0h10"/>',
  menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
  link: '<path d="m10 13 4-4m-6 6-2 2a4 4 0 0 1-6-6l5-5a4 4 0 0 1 6 0m2 2 2-2a4 4 0 0 1 6 6l-5 5a4 4 0 0 1-6 0"/>',
  key: '<circle cx="7" cy="9" r="5"/><path d="m11 13 9 9m-5-5 3-3m0 6 3-3"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  cache: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 4 16 4 16 0V5M4 12c0 4 16 4 16 0"/>',
  plug: '<path d="M8 3v5m8-5v5M5 8h14v3a7 7 0 0 1-7 7v4M5 8v3a7 7 0 0 0 7 7"/>',
  activity: '<path d="M2 12h5l3-8 4 16 3-8h5"/>',
  send: '<path d="m22 2-7 20-4-9-9-4ZM22 2 11 13"/>',
  save: '<path d="M4 3h14l3 3v15H3V3ZM7 3v6h10V3M7 21v-8h10v8"/>',
};
function icon(name) {
  return (
    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">` +
    `${icons[name] || icons.info}</svg>`
  );
}
const esc = (v) =>
  String(v ?? '').replace(
    /[&<>"']/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c],
  );
const state = {
  games: [],
  providers: [],
  settings: {
    enabled: true,
    theme: 'system',
    accent: '#8063c5',
    zoom: 100,
    sourceLanguage: 'auto',
    targetLanguage: 'zh-CN',
    concurrency: 2,
    prefetchEnabled: true,
    prefetchLines: 3,
  },
  stats: {},
  version: '0.7.0',
  token: '',
  route: 'library',
  gameId: '',
  view: localStorage.getItem('libraryView') || 'grid',
  search: '',
  sort: 'recent',
  translationPage: 1,
  translationQuery: '',
  logs: { gameId: '', level: '', module: '', q: '', auto: true },
  glossaryQuery: '',
  diagnostics: null,
  runtimes: {},
  dirty: false,
  updateInProgress: false,
};
const main = document.getElementById('main');
const navItems = [
  ['library', 'library', '游戏库'],
  ['ai', 'ai', 'AI 翻译'],
  ['translations', 'translate', '译文编辑器'],
  ['glossary', 'book', '游戏词表'],
  ['fonts', 'edit', '字体制作'],
  ['scripts', 'book', '剧本翻译'],
  ['logs', 'logs', '运行日志'],
];
document.getElementById('navigation').innerHTML = navItems
  .map(
    ([route, img, label]) =>
      `<a href="#${route}" class="nav-link" data-nav="${route}">${icon(img)}<span>${label}</span></a>`,
  )
  .join('');
document.querySelectorAll('[data-icon]').forEach((el) => (el.innerHTML = icon(el.dataset.icon)));

async function api(path, { method = 'GET', body, download = false } = {}) {
  const headers = { 'X-Toolkit-Token': state.token };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const response = await fetch(path, {
    method,
    headers,
    credentials: 'same-origin',
    body: body === undefined ? undefined : JSON.stringify(body),
    cache: 'no-store',
  });
  if (!response.ok) {
    let data;
    try {
      data = await response.json();
    } catch {
      data = { error: `请求失败（${response.status}）` };
    }
    const error = new Error(data.error || `请求失败（${response.status}）`);
    error.detail = data.detail;
    error.status = response.status;
    throw error;
  }
  if (download) {
    const blob = await response.blob();
    const cd = response.headers.get('Content-Disposition') || '';
    const utf = cd.match(/filename\*=UTF-8''([^;]+)/i),
      normal = cd.match(/filename="?([^";]+)/i);
    let name = utf ? decodeURIComponent(utf[1]) : normal ? normal[1] : 'RikaTranslator-export.json';
    const url = URL.createObjectURL(blob),
      link = document.createElement('a');
    link.href = url;
    link.download = name;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    return;
  }
  if (response.status === 204) return null;
  const text = await response.text();
  return text ? JSON.parse(text) : null;
}
function toast(message, type = 'success', detail = '') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML =
    `${icon(type === 'error' ? 'warning' : type === 'info' ? 'info' : 'check')}<div>${esc(message)}${
      detail ? `<small>` + `${esc(typeof detail === 'string' ? detail : JSON.stringify(detail))}</small>` : ''
    }</div>` + `<button aria-label="关闭">×</button>`;
  el.querySelector('button').onclick = () => el.remove();
  document.getElementById('toasts').append(el);
  setTimeout(() => el.remove(), type === 'error' ? 12000 : 5500);
}
function errorToast(e) {
  toast(e.message || '操作失败', 'error', e.detail);
}
async function busy(button, work) {
  if (button?.disabled) return;
  const old = button?.innerHTML;
  if (button) {
    button.disabled = true;
    button.innerHTML = `<span class="button-spinner"></span> 处理中`;
  }
  try {
    return await work();
  } catch (e) {
    errorToast(e);
  } finally {
    if (button?.isConnected) {
      button.disabled = false;
      button.innerHTML = old;
    }
  }
}
const gameById = (id) => state.games.find((g) => g.id === id);
const providerById = (id) => state.providers.find((p) => p.id === id);
const listItems = (v) => (Array.isArray(v) ? v : v?.items || []);
function dateText(v) {
  if (!v) return '—';
  const d = new Date(v);
  return Number.isNaN(d.valueOf()) ? String(v) : d.toLocaleString('zh-CN', { hour12: false });
}
function number(v) {
  return typeof v === 'number' ? v.toLocaleString('zh-CN') : '—';
}
function currentGame() {
  return gameById(state.gameId);
}
function engineLabel(g) {
  return g?.engine || '未知引擎';
}
function capabilityLabel(g) {
  return (
    {
      'experimental-embedded': '试验内嵌',
      'detection-only': '仅识别',
      'existing-plugin': '已有插件',
      'experimental-hook': '试验 Hook',
    }[g?.capability] || '待调查'
  );
}
function capabilityTone(g) {
  return ['experimental-embedded', 'experimental-hook'].includes(g?.capability)
    ? 'blue'
    : g?.capability === 'existing-plugin'
      ? 'orange'
      : '';
}
function adapterLabel(g) {
  if (g?.capability === 'experimental-hook') return hookSnapshots[g.id]?.active ? 'Hook 已连接' : '未连接 Hook';
  return (
    { installed: '已安装组件', conflict: '发现组件冲突', 'not-installed': '未安装组件' }[g?.adapterStatus] ||
    '未安装组件'
  );
}
function adapterTone(g) {
  if (g?.capability === 'experimental-hook') return hookSnapshots[g.id]?.active ? 'blue' : '';
  return g?.adapterStatus === 'installed' ? 'green' : g?.adapterStatus === 'conflict' ? 'red' : '';
}
function badge(text, tone = '') {
  return `<span class="badge ${tone}">${esc(text)}</span>`;
}
function notice(text, type = '') {
  return (
    `<div class="notice ${type}">${icon(type === 'warning' || type === 'error' ? 'warning' : 'info')}<div>` +
    `${text}</div>` +
    `</div>`
  );
}
function pageHead(title, description, actions = '', eyebrow = '') {
  return (
    `<div class="page-head"><div class="page-head-left">${
      eyebrow ? `<div class="eyebrow">${esc(eyebrow)}</div>` : ''
    }<h1>` +
    `${esc(title)}</h1>` +
    `<p>${description}</p>` +
    `</div><div class="head-actions">${actions}</div>` +
    `</div>`
  );
}
function empty(title, description, action = '', img = 'game') {
  return (
    `<div class="empty-state"><div class="empty-illustration">${icon(img)}</div><h2>${esc(title)}</h2><p>` +
    `${description}</p>` +
    `${action}</div>`
  );
}
function statsCard(title, value, img, tone = '', stat = '') {
  return (
    `<div class="stat-card"><div class="stat-icon ${tone}">${icon(img)}</div><div><strong${stat ? ` data-stat="${esc(stat)}"` : ''}>` +
    `${esc(value)}</strong>` +
    `<small>${esc(title)}</small>` +
    `</div></div>`
  );
}
function providerOptions(value, inherit = false) {
  return `${inherit ? '<option value="">继承全局服务</option>' : '<option value="">请选择翻译服务</option>'}${state.providers
    .map(
      (p) =>
        `<option value="${esc(p.id)}" ${p.id === value ? 'selected' : ''}>` +
        `${esc(p.name)} · ${esc(p.model || '未设置模型')}</option>`,
    )
    .join('')}`;
}
function languageOptions(value, source = false) {
  const list = source
    ? [
        ['auto', '自动判断'],
        ['ja', '日语'],
        ['en', '英语'],
        ['ko', '韩语'],
        ['zh-CN', '简体中文'],
        ['zh-TW', '繁体中文'],
      ]
    : [
        ['zh-CN', '简体中文'],
        ['zh-TW', '繁体中文'],
        ['en', '英语'],
        ['ja', '日语'],
        ['ko', '韩语'],
      ];
  if (value && !list.some(([v]) => v === value)) list.push([value, value]);
  return list
    .map(([v, label]) => `<option value="${esc(v)}" ${v === value ? 'selected' : ''}>${esc(label)}</option>`)
    .join('');
}
function gameOptions(value, allLabel = '全部游戏') {
  return `<option value="">${esc(allLabel)}</option>${state.games
    .map((g) => `<option value="${esc(g.id)}" ${g.id === value ? 'selected' : ''}>` + `${esc(g.name)}</option>`)
    .join('')}`;
}
function applyTheme() {
  const choice = state.settings.theme || 'system';
  document.documentElement.dataset.theme =
    choice === 'system' ? (matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light') : choice;
  const accent = state.settings.accent;
  if (/^#[\da-f]{6}$/i.test(accent || '')) {
    document.documentElement.style.setProperty('--accent', accent);
    document.documentElement.style.setProperty('--accent-soft', `color-mix(in srgb,${accent} 11%,var(--surface))`);
  }
  const zoom = Number(state.settings.zoom) || 100;
  document.body.style.zoom = `${Math.max(80, Math.min(130, zoom))}%`;
  document.querySelector('[data-action="theme-cycle"]').innerHTML = icon(
    choice === 'dark' ? 'moon' : choice === 'light' ? 'sun' : 'monitor',
  );
}
matchMedia('(prefers-color-scheme:dark)').addEventListener('change', () => {
  if (state.settings.theme === 'system') applyTheme();
});
async function refreshBootstrap() {
  const data = await api('/api/bootstrap');
  state.games = data.games || [];
  state.providers = data.providers || [];
  state.settings = { ...state.settings, ...data.settings };
  state.stats = data.stats || {};
  state.version = data.version || '0.7.0';
  document.getElementById('version').textContent = `v${state.version}`;
  applyTheme();
  return data;
}
let renderSequence = 0,
  renderedHash = location.hash;
function readRoute() {
  const [page, gameId] = location.hash.slice(1).split('/');
  const known = ['library', 'game', 'ai', 'translations', 'glossary', 'fonts', 'scripts', 'logs', 'settings'];
  state.route = known.includes(page) ? page : 'library';
  state.gameId = gameId ? decodeURIComponent(gameId) : '';
}
async function render() {
  const sequence = ++renderSequence;
  state.dirty = false;
  readRoute();
  document
    .querySelectorAll('[data-nav]')
    .forEach((link) =>
      link.classList.toggle('active', link.dataset.nav === (state.route === 'game' ? 'library' : state.route)),
    );
  const label =
    state.route === 'game'
      ? '游戏详情'
      : state.route === 'settings'
        ? '设置'
        : navItems.find(([r]) => r === state.route)?.[2] || '游戏库';
  document.getElementById('breadcrumb').innerHTML =
    `工作空间 <span>/</span> ${esc(label)}${state.gameId && currentGame() ? ` <span>/</span> ${esc(currentGame().name)}` : ''}`;
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebar-backdrop').classList.remove('open');
  main.innerHTML = '<div class="page-loading"><span class="spinner"></span><p>正在读取本地数据…</p></div>';
  try {
    if (state.route === 'library') renderLibrary();
    else if (state.route === 'game') renderGame();
    else if (state.route === 'ai') renderAi();
    else if (state.route === 'translations') await renderTranslations(sequence);
    else if (state.route === 'glossary') await renderGlossary(sequence);
    else if (state.route === 'fonts') await renderFontMaker(sequence);
    else if (state.route === 'scripts') await renderScriptTranslation(sequence);
    else if (state.route === 'logs') await renderLogs(sequence);
    else if (state.route === 'settings') await renderSettings(sequence);
  } catch (e) {
    if (sequence === renderSequence)
      main.innerHTML = `${pageHead(label, '暂时无法读取页面数据')} ${empty('读取失败', esc(e.message), '<button class="btn primary" data-action="refresh-page">重试</button>', 'warning')}`;
    errorToast(e);
  }
}
function renderLibrary() {
  const installed = state.games.filter((g) => g.adapterStatus === 'installed').length;
  let games = state.games.filter((g) =>
    `${g.name} ${g.executablePath} ${engineLabel(g)}`.toLowerCase().includes(state.search.toLowerCase()),
  );
  games.sort((a, b) =>
    state.sort === 'name'
      ? a.name.localeCompare(b.name, 'zh-CN')
      : state.sort === 'engine'
        ? engineLabel(a).localeCompare(engineLabel(b))
        : new Date(b.createdAt || 0) - new Date(a.createdAt || 0),
  );
  main.innerHTML =
    `${pageHead(
      '游戏库',
      '管理游戏、适配组件与属于你的汉化配置。',
      `<button class="btn primary" data-action="add-game">` + `${icon('plus')}添加游戏</button>`,
      'YOUR GAME LIBRARY',
    )}<div class="stats-grid">` +
    `${statsCard('已添加游戏', state.games.length, 'game')}${statsCard('已安装适配组件', installed, 'plug', 'green')}${statsCard('本地翻译记录', number(state.stats.translationCount ?? state.stats.completed), 'translate', 'purple')}${statsCard('已配置翻译服务', state.providers.length, 'ai', 'orange')}</div>` +
    `<div class="toolbar"><div class="search-field"><input id="library-search" placeholder="搜索游戏、路径或引擎" value="${esc(state.search)}" aria-label="搜索游戏">` +
    `</div><div class="toolbar-end"><select id="library-sort" style="width:130px" aria-label="游戏排序"><option value="recent" ${state.sort === 'recent' ? 'selected' : ''}>` +
    `最近添加</option><option value="name" ${state.sort === 'name' ? 'selected' : ''}>` +
    `按名称排序</option><option value="engine" ${state.sort === 'engine' ? 'selected' : ''}>` +
    `按引擎排序</option></select><div class="view-toggle"><button class="btn square ${state.view === 'grid' ? 'active' : 'ghost'}" data-action="library-view" data-value="grid" title="卡片视图" aria-label="卡片视图">` +
    `${icon('library')}</button>` +
    `<button class="btn square ${state.view === 'list' ? 'active' : 'ghost'}" data-action="library-view" data-value="list" title="列表视图" aria-label="列表视图">` +
    `${icon('list')}</button>` +
    `</div></div></div>${
      games.length
        ? `<div class="${state.view === 'grid' ? 'games-grid' : 'game-list'}">` +
          `${games.map((g, i) => gameCard(g, i)).join('')}</div>`
        : state.games.length
          ? empty('没有找到游戏', '换个名称、路径或引擎关键词试试。', '', 'search')
          : empty(
              '把下一段故事，读成中文',
              '添加游戏启动程序，查看引擎与适配能力。配置自己的翻译服务后，文字会按需翻译并保存在本机。',
              `<button class="btn primary" data-action="add-game">` + `${icon('plus')}添加第一个游戏</button>`,
            )
    }${
      !state.games.length
        ? `<div class="onboarding">` +
          `<div class="step"><span class="step-number">1</span><div><h3>连接自己的 AI</h3><p>填写 OpenAI 兼容接口、Key 和模型。</p></div>` +
          `</div><div class="step"><span class="step-number">2</span><div><h3>添加游戏</h3><p>选择启动程序，检查引擎和组件。</p></div></div>` +
          `<div class="step"><span class="step-number">3</span><div><h3>安装适配，开始阅读</h3><p>可用能力以实际适配结果为准。</p></div></div></div>`
        : ''
    }<div class="section-gap">` +
    `${notice('引擎识别与翻译适配分别记录。<b>试验内嵌</b>需要在具体游戏中验证；未适配的游戏会如实显示状态。')}</div>`;
  document.getElementById('library-search').addEventListener(
    'input',
    debounce((e) => {
      const start = e.target.selectionStart;
      state.search = e.target.value;
      renderLibrary();
      const input = document.getElementById('library-search');
      input.focus();
      input.setSelectionRange(start, start);
    }, 180),
  );
  document.getElementById('library-sort').onchange = (e) => {
    state.sort = e.target.value;
    renderLibrary();
  };
}
function gameCard(g, i) {
  const colors = ['#5c83d4', '#8e72c6', '#528f8c', '#c09055', '#bd7389'],
    tone = adapterTone(g),
    list = state.view === 'list';
  const actions =
    `<div class="game-library-actions"><button class="btn ${list ? 'small' : 'square ghost'}" data-action="launch-game" data-id="${esc(g.id)}" title="启动游戏" aria-label="启动 ${esc(g.name)}">` +
    `${icon('play')}${list ? '启动' : ''}</button>` +
    `<button class="btn small ghost" data-action="remove-game" data-id="${esc(g.id)}" title="从游戏库移除" aria-label="从游戏库移除 ${esc(g.name)}">` +
    `${icon('trash')}移除</button>` +
    `</div>`;
  if (list)
    return (
      `<div class="game-row" data-action="game-detail" data-id="${esc(g.id)}" tabindex="0" role="link"><div class="game-row-icon">` +
      `${icon('game')}</div>` +
      `<div class="game-row-copy"><h3>${esc(g.name)}</h3>` +
      `<p>${esc(g.executablePath)}</p>` +
      `</div><div class="badges">${badge(engineLabel(g), 'blue')}${badge(capabilityLabel(g), capabilityTone(g))}</div>` +
      `${badge(adapterLabel(g), tone)}${actions}</div>`
    );
  return (
    `<div class="game-card" data-action="game-detail" data-id="${esc(g.id)}" tabindex="0" role="link" style="--game-color:${colors[i % colors.length]}">` +
    `<div class="game-art">${icon('game')}${badge(engineLabel(g))}</div>` +
    `<div class="game-card-body"><h3>${esc(g.name)}</h3>` +
    `<p class="path" title="${esc(g.executablePath)}">` +
    `${esc(g.executablePath)}</p>` +
    `<div class="game-card-bottom">${badge(adapterLabel(g), tone)}${actions}</div>` +
    `</div></div>`
  );
}
function gameCapabilities(g, r) {
  const supported = ['experimental-embedded', 'existing-plugin', 'experimental-hook'].includes(g.capability),
    installed = r ? r.adapterInstalled : g.adapterStatus === 'installed';
  const received = Number(r?.received) || 0,
    delivered = Number(r?.delivered) || 0;
  const waiting =
    g.capability === 'experimental-hook'
      ? '等待 Hook 连接'
      : !supported
        ? '尚未提供组件'
        : !installed
          ? '等待安装'
          : '等待游戏取词';
  return (
    `<div class="capability ${g.engine && g.engine !== 'Unknown' ? 'available' : ''}">${icon('search')}<strong>` +
    `引擎识别</strong><small>${esc(engineLabel(g))}<span class="capability-engine-version">` +
    `${esc(g.engineVersion || '版本未知')}</span>` +
    `</small></div><div class="capability ${received > 0 ? 'available' : ''}">` +
    `${icon('translate')}<strong>` +
    `运行时取词</strong><small>${received > 0 ? '已收到游戏文字' : waiting}</small>` +
    `</div><div class="capability ${delivered > 0 ? 'available' : ''}">` +
    `${icon('monitor')}<strong>` +
    `${r?.deliveryMode === 'floating' ? '翻译浮窗' : '译文回传'}</strong>` +
    `<small>${delivered > 0 ? (r?.deliveryMode === 'floating' ? '已获得浮窗译文' : '已回传 · 待画面验证') : !supported ? '尚未提供组件' : g.capability === 'experimental-hook' ? '等待 Hook 译文' : !installed ? '等待安装' : '等待译文回传'}</small>` +
    `</div>`
  );
}
function runtimeCard(g) {
  return (
    `<section class="card runtime-card" id="game-runtime" data-game-id="${esc(g.id)}"><div class="card-header">` +
    `<div><h2>${icon('activity')}运行诊断</h2>` +
    `<p>每 3 秒更新，按日志和实际请求记录进度。</p></div><button class="btn ghost small" data-action="refresh-runtime" data-id="${esc(g.id)}">` +
    `${icon('refresh')}刷新</button>` +
    `</div><div id="runtime-body" aria-live="polite">${runtimeBody(g, state.runtimes[g.id])}</div>` +
    `<div class="adapter-actions"><button class="btn small" data-action="runtime-advice" data-id="${esc(g.id)}">${icon('info')}查看诊断建议</button>` +
    `<a class="btn small" href="#logs/${encodeURIComponent(g.id)}">` +
    `${icon('logs')}查看游戏日志</a>` +
    `</div></section>`
  );
}
function runtimeBody(g, r) {
  if (!r) return '<p class="card-description">正在读取组件和运行状态…</p>';
  const globalPaused = (r.globalTranslationEnabled ?? state.settings.enabled) === false,
    gamePaused = (r.gameTranslationEnabled ?? g.enabled) === false,
    paused = globalPaused || gamePaused;
  const pauseMessage =
    r.pauseReason ||
    (globalPaused
      ? '全局翻译已暂停。游戏仍可发送文字，但不会调用翻译服务。请启用全局翻译后重新启动游戏。'
      : '此游戏的翻译开关已关闭。请启用此游戏翻译后重新启动游戏。');
  const pauseNotice = paused
    ? `<div class="section-gap">${notice(esc(pauseMessage), 'warning')}<div class="adapter-actions">${
        globalPaused
          ? `<button class="btn primary" data-action="resume-game-translation" data-scope="global" data-id="${esc(g.id)}">` +
            `${icon('play')}启用全局翻译</button>`
          : ''
      }${
        gamePaused
          ? `<button class="btn" data-action="resume-game-translation" data-scope="game" data-id="${esc(g.id)}">` +
            `${icon('play')}启用此游戏翻译</button>`
          : ''
      }</div>` + `</div>`
    : '';
  const stages = {
    'not-installed': ['等待安装适配组件', '', '安装后，从工具启动游戏，再查看取词和回传记录。'],
    ready: ['组件已部署', 'blue', '从工具启动游戏，等待加载器和游戏文字。'],
    launched: ['游戏已启动，等待取词', 'blue', '正在检查新产生的加载器日志和游戏取词请求。'],
    'loader-detected': ['发现加载器日志', 'blue', '已发现本次启动产生的加载器日志；继续等待翻译组件和游戏文字。'],
    'translator-attempted': ['发现翻译组件加载记录', 'blue', '日志出现了翻译组件的加载尝试，实际取词以收到请求为准。'],
    receiving: ['已收到游戏文字', 'green', '文字已到达翻译服务，正在等待译文回传。'],
    delivered: ['已回传译文', 'green', '翻译服务已向游戏适配组件回传译文，请在游戏画面中验证显示效果。'],
    error: ['运行或翻译出现问题', 'red', '查看下方错误和日志，确认组件加载或服务请求失败的原因。'],
  };
  if (g.capability === 'experimental-hook' || ['floating', 'hook-embedded'].includes(r.deliveryMode)) {
    stages['not-installed'] = ['等待连接文本 Hook', '', '连接游戏后，显示对话并选择文字通道。'];
    stages.delivered = ['浮窗已更新', 'green', '译文已获得并交给翻译浮窗，可在游戏详情查看最近文字。'];
    stages['translator-attempted'] = ['Hook 已连接', 'blue', '在游戏中显示对话后，选择实际对话通道。'];
    stages.launched = ['Hook 正在连接', 'blue', '等待原生组件连接与文字通道。'];
  }
  if (r.deliveryMode === 'hook-embedded')
    stages.delivered = ['内嵌组件已接收译文', 'green', '已确认回填响应，字体与画面效果需在游戏中验证。'];
  const isHook = g.capability === 'experimental-hook' || ['floating', 'hook-embedded'].includes(r.deliveryMode),
    isUnreal = !isHook && g.engine === 'Unreal Engine',
    isRpg = !isHook && ['RPG Maker MV', 'RPG Maker MZ'].includes(g.engine),
    isNw = !isHook && g.engine === 'NW.js';
  stages.paused = [
    globalPaused ? '全局翻译已暂停' : '此游戏翻译已暂停',
    'orange',
    isHook || isNw
      ? '启用翻译后继续处理当前原文；当前不会请求翻译服务。'
      : '启用翻译后再启动游戏；当前不会请求翻译服务。',
  ];
  if (isUnreal) {
    stages['loader-detected'] = ['插件已启动', 'blue', '收到当前 UE4SS 翻译插件的心跳，等待游戏文字。'];
    stages['translator-attempted'] = ['文字钩子已注册', 'blue', '插件已注册 UMG 文字钩子；实际取词以收到请求为准。'];
  }
  const entry = stages[paused && r.adapterInstalled ? 'paused' : r.stage] || [
    '等待运行证据',
    '',
    '状态将根据日志和取词请求更新。',
  ];
  const received = Number(r.received) || 0,
    translated = Number(r.translated) || 0,
    delivered = Number(r.delivered) || 0,
    failed = Number(r.failed) || 0,
    hits = Number(r.cacheHits) || 0;
  const steps = isHook
    ? [
        ['Hook 会话', !!r.adapterInstalled, '已建立会话'],
        ['游戏连接', !!r.translatorAttempted, '原生组件已连接'],
        ['对话取词', received > 0, '选定文本通道'],
        [
          r.deliveryMode !== 'hook-embedded' ? '浮窗译文' : '内嵌回传',
          delivered > 0,
          r.deliveryMode !== 'hook-embedded' ? '已获得译文' : '内嵌组件已接收，待画面验证',
        ],
      ]
    : isRpg || isNw
      ? [
          ['组件部署', !!r.adapterInstalled, '安装清单'],
          ['插件取词', received > 0, '已收到游戏插件请求'],
          ['译文回传', delivered > 0, '待游戏画面验证'],
        ]
      : [
          ['组件部署', !!r.adapterInstalled, '安装清单'],
          [isUnreal ? '插件心跳' : '加载器日志', !!r.loaderLogFound, isUnreal ? '当前游戏进程' : '本次启动的新日志'],
          [isUnreal ? '文字钩子' : '组件加载记录', !!r.translatorAttempted, isUnreal ? '插件已注册' : '加载尝试'],
          ['收到游戏文字', received > 0, '适配组件请求'],
          ['回传译文', delivered > 0, '待游戏画面验证'],
        ];
  const isIl2Cpp = String(g.backend || '')
    .toLowerCase()
    .includes('il2cpp');
  const notes = Array.isArray(r.notes) ? r.notes : [];
  return (
    `<div class="runtime-stage">${badge(entry[0], entry[1])}${badge(r.gameRunning ? '游戏正在运行' : '游戏未运行', r.gameRunning ? 'green' : '')}</div>` +
    `<p class="card-description runtime-explanation">${esc(entry[2])}</p>` +
    `${pauseNotice}<div class="runtime-steps">` +
    `${steps
      .map(
        ([label, yes, hint]) =>
          `<div class="runtime-step ${yes ? 'complete' : ''}">` +
          `<span>${icon(yes ? 'check' : 'clock')}</span>` +
          `<div><strong>${esc(label)}</strong>` +
          `<small>${esc(yes ? hint : '等待证据')}</small>` +
          `</div></div>`,
      )
      .join('')}</div>` +
    `<div class="runtime-counts">${[
      ['收到取词', received],
      ['获得译文', translated],
      ['响应已发送', delivered],
      ['失败请求', failed],
    ]
      .map(([label, value]) => `<div><strong>${number(value)}</strong><small>${esc(label)}</small></div>`)
      .join(
        '',
      )}</div><div class="runtime-last-seen"><span>最近取词</span><span>${esc(dateText(r.lastSeen))}</span></div>${
      isIl2Cpp && r.adapterInstalled && received === 0
        ? `<div class="section-gap">` +
          `${notice('IL2CPP 首次启动可能需要生成 Interop 文件，请等待游戏加载。是否完成、是否失败，以本次启动日志为准。')}</div>`
        : ''
    }${r.lastError ? `<div class="section-gap">` + `${notice(esc(r.lastError), 'error')}</div>` : ''}${
      notes.length
        ? `<ul class="runtime-notes">` + `${notes.map((note) => `<li>` + `${esc(note)}</li>`).join('')}</ul>`
        : ''
    }<p class="tiny subtle section-gap">` +
    `回传统计证明适配组件与翻译服务之间已通信；中文字体、文字替换和画面显示仍需在游戏中验证。</p>`
  );
}
async function showRuntimeAdvice(id) {
  const g = gameById(id);
  if (!g) return;
  const report = await api(`/api/games/${encodeURIComponent(id)}/diagnostics`);
  const runtime = report.runtime || {};
  const issues = (report.issues || []).slice(0, 12);
  let next = '请先在游戏中显示一段对白，再检查取词和回传状态。';
  if (!runtime.adapterInstalled && g.capability !== 'experimental-hook')
    next = '先查看安装检查；安装记录本身不代表组件已成功加载。';
  else if (!runtime.launchedAt) next = '尚无通过梨花启动的本次日志证据；可保存进度后从梨花启动游戏，再检查状态。';
  else if (g.engine === 'Unity' && runtime.gameRunning && !runtime.loaderLogFound && !runtime.received)
    next = '本次尚未看到加载器日志或取词。可检查进程架构、组件安装位置与启动权限；没有黑色窗口本身不能证明加载失败。';
  else if (runtime.delivered > 0) next = '译文已回传，请在游戏画面中确认文字和字体显示。';
  modal(
    '游戏诊断建议',
    '根据当前运行状态和可读取日志整理；历史记录不会当作本次运行证据。',
    `<p><strong>${esc(report.summary || '等待运行证据')}</strong></p>` +
      `<p class="card-description section-gap">${esc(next)}</p>` +
      `${
        issues.length
          ? `<div class="script-review-list section-gap">${issues
              .map(
                (issue) =>
                  `<div class="script-review-item"><strong>${esc(issue.title)}</strong>` +
                  `<p class="tiny subtle">${issue.scope === 'current' ? '本次运行' : '历史记录'}${issue.count ? ` · ${number(issue.count)} 次` : ''}</p>` +
                  `<p>${esc(issue.suggestion)}</p></div>`,
              )
              .join('')}</div>`
          : '<p class="tiny subtle section-gap">目前没有识别到具体错误，仍需结合游戏画面检查。</p>'
      }` +
      `<div class="form-actions"><a class="btn" href="#logs/${encodeURIComponent(id)}" data-action="close-modal">查看游戏日志</a>` +
      `<button class="btn" type="button" data-action="close-modal">关闭</button></div>`,
    { wide: true },
  );
}

function scriptCompatibilityCard(g) {
  return (
    `<section class="card"><div class="card-header"><h2>${icon('book')}剧本兼容情况</h2>` +
    `<button class="btn ghost small" data-action="refresh-script-compat" data-id="${esc(g.id)}">${icon('refresh')}重新检查</button></div>` +
    `<div id="script-compatibility" data-game-id="${esc(g.id)}"><p class="card-description">正在检查候选资源…</p></div></section>`
  );
}
async function refreshScriptCompatibility(id) {
  const holder = document.getElementById('script-compatibility');
  if (!holder || holder.dataset.gameId !== id) return;
  try {
    const result = await api(`/api/script-translation/games/${encodeURIComponent(id)}/compatibility`);
    if (!holder.isConnected || holder.dataset.gameId !== id) return;
    holder.innerHTML =
      `<div class="info-list">` +
      `<div class="info-row"><span>引擎识别</span><span>${esc(result.engine || '未知')} ${esc(result.engineVersion || '')} · ${esc(result.architecture || '架构未知')}</span></div>` +
      `<div class="info-row"><span>剧本提取</span><span>${esc(result.extractionState)}</span></div>` +
      `<div class="info-row"><span>汉化补丁</span><span>${esc(result.patchState)}</span></div>` +
      `<div class="info-row"><span>适配格式</span><span>${esc(result.format || '暂无可用信息')}</span></div></div>` +
      `${result.detail ? `<p class="tiny subtle section-gap">${esc(result.detail)}</p>` : ''}` +
      `<p class="tiny subtle section-gap">${esc(result.note)}</p><div class="adapter-actions"><a class="btn small" href="#scripts">${icon('book')}打开剧本翻译</a></div>`;
  } catch (error) {
    if (holder.isConnected) holder.innerHTML = notice(`无法检查剧本兼容情况：${esc(error.message)}`, 'warning');
  }
}
let runtimePolling = false;
async function refreshRuntime(id, reportErrors = false) {
  if (!id || runtimePolling) return;
  runtimePolling = true;
  try {
    const runtime = await api(`/api/games/${encodeURIComponent(id)}/runtime`);
    state.runtimes[id] = runtime;
    if (state.route !== 'game' || state.gameId !== id) return;
    const card = document.getElementById('game-runtime'),
      g = gameById(id);
    if (!card || card.dataset.gameId !== id || !g) return;
    const body = document.getElementById('runtime-body');
    if (body) body.innerHTML = runtimeBody(g, runtime);
    const capabilities = document.getElementById('game-capabilities');
    if (capabilities) capabilities.innerHTML = gameCapabilities(g, runtime);
    void refreshHook(id);
  } catch (e) {
    if (reportErrors) errorToast(e);
    const card = document.getElementById('game-runtime'),
      body = document.getElementById('runtime-body');
    if (card?.dataset.gameId === id && body && !state.runtimes[id])
      body.innerHTML = notice(`暂时无法读取运行诊断：${esc(e.message)}。点击刷新重试。`, 'warning');
  } finally {
    runtimePolling = false;
  }
}
setInterval(() => {
  if (state.route === 'game' && !document.hidden && !document.getElementById('modal-root').childElementCount)
    void refreshRuntime(state.gameId);
}, 3000);
function renderGame() {
  const g = currentGame();
  if (!g) {
    main.innerHTML = empty(
      '游戏记录不存在',
      '游戏可能已从游戏库移除。',
      '<a class="btn primary" href="#library">返回游戏库</a>',
    );
    return;
  }
  const p = providerById(g.providerId || state.settings.providerId);
  const supported = ['experimental-embedded', 'existing-plugin'].includes(g.capability),
    hookSupported = g.capability === 'experimental-hook';
  const installed = g.adapterStatus === 'installed';
  const warning = [...(g.warnings || [])];
  main.innerHTML =
    `<a class="back-link" href="#library">${icon('back')}返回游戏库</a><div class="detail-hero"><div class="detail-icon">` +
    `${icon('game')}</div>` +
    `<div class="detail-hero-copy"><h1>${esc(g.name)}</h1>` +
    `<p>${esc(g.executablePath)}</p>` +
    `<div class="badges">${badge(engineLabel(g), 'blue')}${badge(g.architecture || '架构未知')}${badge(capabilityLabel(g), capabilityTone(g))}<span id="game-adapter-status">` +
    `${badge(adapterLabel(g), adapterTone(g))}</span>` +
    `</div></div><div class="actions"><button class="btn" data-action="open-folder" data-kind="game" data-id="${esc(g.id)}">` +
    `${icon('folder')}游戏目录</button>` +
    `<button class="btn primary" data-action="launch-game" data-id="${esc(g.id)}">` +
    `${icon('play')}启动游戏</button>` +
    `</div></div><div class="grid-two game-detail-grid"><div class="stack"><section class="card"><div class="card-header">` +
    `<h2>${icon('plug')}引擎适配</h2>` +
    `<button class="btn ghost small" data-action="recheck-game" data-id="${esc(g.id)}">` +
    `${icon('refresh')}重新检测</button>` +
    `</div><div id="game-capabilities" class="capabilities">${gameCapabilities(g, state.runtimes[g.id])}</div>` +
    `${notice(hookSupported ? '已提供文本 Hook 与翻译浮窗，请在下方连接游戏并选择对话通道。可内嵌通道需要单独开启并验证。' : supported ? '已提供该类型的适配路线，实际取词和内嵌效果需要启动游戏后验证。安装成功仅表示组件已部署。' : '当前可识别该游戏，但尚未提供对应取词和内嵌组件。可查看日志和检测结果。', supported || hookSupported ? '' : 'warning')}${
      g.detectionNotes
        ? `<p class="card-description section-gap">` +
          `${esc(typeof g.detectionNotes === 'string' ? g.detectionNotes : JSON.stringify(g.detectionNotes))}</p>`
        : ''
    }${warning
      .map((w) => `<div class="section-gap">` + `${notice(esc(w), 'warning')}</div>`)
      .join('')}<div class="adapter-actions">` +
    `${
      hookSupported
        ? `<button class="btn primary" data-action="hook-start" data-id="${esc(g.id)}">` +
          `${icon('play')}连接文本 Hook</button>`
        : installed
          ? `<button class="btn" data-action="uninstall-game" data-id="${esc(g.id)}">` +
            `${icon('shield')}卸载与恢复</button>`
          : `<button class="btn primary" data-action="install-game" data-id="${esc(g.id)}" ${!supported ? 'disabled' : ''}>` +
            `${icon('download')}检查并安装适配</button>`
    }<button class="btn" data-action="cleanup-game" data-id="${esc(g.id)}">` +
    `${icon('trash')}清理残留</button>` +
    `<a class="btn" href="#logs/${encodeURIComponent(g.id)}">` +
    `${icon('logs')}查看游戏日志</a>` +
    `</div></section>${scriptCompatibilityCard(g)}${hookCard(g)}${runtimeCard(g)}</div>` +
    `<div class="stack"><section class="card"><div class="card-header"><div><h2>${icon('ai')}游戏翻译设置</h2>` +
    `<p>未单独选择服务时，继承全局配置。</p></div></div>${notice(g.capability === 'experimental-hook' || g.galgame?.enabled ? '修改语言或服务后，Hook 会取消旧请求并重新处理当前原文。内嵌从下一次取词起生效；浮窗和游戏内嵌的显示效果请分别检查。' : 'Ren’Py / RPG Maker / Unreal 更改译文或配置后请重启游戏。Unity 与 Unreal 修改语言需退出游戏、卸载再安装以刷新配置。Unity 的旧译文缓存还需先备份，再按需要处理。')}<div class="section-gap">` +
    `</div><form id="game-settings"><label class="field">游戏名称<input name="name" value="${esc(g.name)}" required maxlength="160">` +
    `</label><label class="field">翻译服务<select name="providerId">${providerOptions(g.providerId, true)}</select>` +
    `<small>当前生效：${p ? `${esc(p.name)} / ${esc(p.model || '未设置模型')}` : '尚未选择服务'}</small>` +
    `</label><div class="field-row"><label class="field">原文语言<select name="sourceLanguage">${languageOptions(g.sourceLanguage || state.settings.sourceLanguage, true)}</select>` +
    `</label><label class="field">目标语言<select name="targetLanguage">${languageOptions(g.targetLanguage || state.settings.targetLanguage)}</select>` +
    `</label></div><label class="field">游戏背景 / 翻译上下文<textarea name="context" placeholder="可填写故事背景、角色关系或需要保持的语气">${esc(g.context)}</textarea>` +
    `<small>仅将你填写的背景随翻译文字发送给所选服务。</small></label><div class="switch-row"><div class="switch-copy"><strong>启用此游戏的翻译</strong>` +
    `<small>关闭后适配保留，新文字不请求翻译。</small></div><label class="switch"><input name="enabled" type="checkbox" ${g.enabled !== false ? 'checked' : ''} aria-label="启用此游戏的翻译">` +
    `<span></span></label></div><div class="form-actions"><button class="btn primary" type="submit">${icon('save')}保存游戏设置</button>` +
    `</div></form></section>${fontCard(g)}${verificationCard(g)}<section class="card">` +
    `<div class="card-header"><h2>${icon('info')}游戏信息</h2>` +
    `</div><div class="info-list"><div class="info-row"><span>游戏引擎</span><span>${esc(g.engine)} ${esc(g.engineVersion)}</span>` +
    `</div><div class="info-row"><span>运行时 / 后端</span><span>${esc(g.backend || '—')}</span>` +
    `</div><div class="info-row"><span>程序架构</span><span>${esc(g.architecture || '未知')}</span>` +
    `</div><div class="info-row"><span>游戏目录</span><span class="mono tiny">${esc(g.directory)}</span>` +
    `</div><div class="info-row"><span>添加时间</span><span>${esc(dateText(g.createdAt))}</span>` +
    `</div></div><div class="divider"></div><button class="btn ghost small" data-action="remove-game" data-id="${esc(g.id)}">` +
    `${icon('trash')}从游戏库移除</button>` +
    `</section></div></div><div class="quick-links section-gap"><a class="quick-link" href="#translations/${encodeURIComponent(g.id)}">` +
    `${icon('translate')}<div>` +
    `<strong>译文编辑器</strong><small>修订译文与管理缓存</small></div></a><a class="quick-link" href="#glossary/${encodeURIComponent(g.id)}">` +
    `${icon('book')}<div>` +
    `<strong>游戏词表</strong><small>统一人名、物品与术语</small></div></a><a class="quick-link" href="#logs/${encodeURIComponent(g.id)}">` +
    `${icon('logs')}<div>` +
    `<strong>运行日志</strong><small>查看取词、请求与安装状态</small></div></a></div>`;
  document.getElementById('game-settings').onsubmit = (e) => {
    e.preventDefault();
    const f = e.target,
      d = new FormData(f);
    busy(f.querySelector('[type=submit]'), async () => {
      await api(`/api/games/${encodeURIComponent(g.id)}`, {
        method: 'PUT',
        body: {
          name: d.get('name'),
          providerId: d.get('providerId') || null,
          sourceLanguage: d.get('sourceLanguage'),
          targetLanguage: d.get('targetLanguage'),
          context: d.get('context'),
          enabled: f.elements.enabled.checked,
        },
      });
      state.dirty = false;
      await refreshBootstrap();
      renderGame();
      toast('游戏设置已保存');
    });
  };
  markDirty('game-settings');
  void refreshRuntime(g.id);
  void refreshScriptCompatibility(g.id);
  void refreshHook(g.id);
  void refreshVerification(g.id);
}
function fontSupported(g) {
  return (
    (g.engine === 'Unity' && ['Mono', 'IL2CPP'].includes(g.backend)) ||
    ["Ren'Py", 'RPG Maker MV', 'RPG Maker MZ'].includes(g.engine) ||
    (g.engine === 'Unreal Engine' && g.architecture === 'x64' && /^5\.7(?:\.|$)/.test(g.engineVersion || ''))
  );
}
function verificationCard(g) {
  return (
    `<section class="card"><div class="card-header"><h2>${icon('shield')}此游戏的验证记录</h2></div><div id="game-verification" data-game-id="${esc(g.id)}">` +
    `<p class="card-description">正在核对游戏文件与测试范围…</p></div></section>`
  );
}
async function refreshVerification(id) {
  const holder = document.getElementById('game-verification');
  if (!holder) return;
  try {
    const result = await api(`/api/games/${encodeURIComponent(id)}/verification`);
    if (!holder.isConnected || holder.dataset.gameId !== id) return;
    holder.innerHTML =
      `${badge({ verified: '已验证', partial: '部分验证', unverified: '未验证' }[result.status] || '未验证', result.status === 'verified' ? 'green' : result.status === 'partial' ? 'blue' : '')}<p class="tiny subtle section-gap">` +
      `${esc(result.note)}</p>` +
      `${(result.records || [])
        .map(
          (record) =>
            `<details class="font-report">` +
            `<summary>${esc(record.date)} · 工具 ${esc(record.toolVersion)} · ${esc(record.game)}</summary>` +
            `<p class="tiny">${esc(record.adapter)}<br>` +
            `${esc(record.method)}</p>` +
            `<div class="info-list">${(record.steps || [])
              .map(
                (step) =>
                  `<div class="info-row">` +
                  `<span>${esc(step.name)}</span>` +
                  `<span>${esc({ passed: '通过', pending: '未验证', failed: '未通过', partial: '部分验证' }[step.status] || step.status)}<small class="muted">` +
                  `${esc(step.note)}</small>` +
                  `</span></div>`,
              )
              .join('')}</div>` +
            `${(record.limits || []).map((note) => `<p class="tiny subtle">` + `${esc(note)}</p>`).join('')}${(
              record.evidence || []
            )
              .map((note) => `<p class="tiny mono">` + `证据：${esc(note)}</p>`)
              .join('')}</details>`,
        )
        .join('')}`;
  } catch (e) {
    if (holder.isConnected) holder.innerHTML = notice('暂时无法读取验证记录：' + esc(e.message), 'warning');
  }
}
function fontSummary(g) {
  const font = g.font || {};
  if (font.mode === 'existing') return '沿用已有 XUnity 字体配置';
  if (font.mode === 'original') return '使用游戏原字体';
  if (font.mode === 'custom')
    return g.engine === 'Unreal Engine'
      ? font.unrealPath
      : g.engine === 'Unity'
        ? `${font.family || '系统字体'}${font.fileName ? ' + ' + font.fileName : ''}`
        : font.fileName || '自定义字体';
  return '自动中文字体';
}
function tmpReportMarkup(report) {
  if (!report) return '';
  const tri = (value) => (value === true ? '是' : value === false ? '否' : '无法确定');
  return (
    `<details class="font-report"><summary>TMP 字体包检查 · Unity ${esc(report.unityVersion || '未知')}</summary>` +
    `${(report.fonts || [])
      .map(
        (f) =>
          `<div class="info-list">` +
          `<div class="info-row"><span>字体资源 / TMP 版本</span><span>${esc(f.name)} / ${esc(f.version || '未知')}</span>` +
          `</div><div class="info-row"><span>静态字符数</span><span>${number(f.characterCount)}</span>` +
          `</div><div class="info-row"><span>测试字符缺失</span><span>${esc(f.missingSample || '未发现')}</span>` +
          `</div><div class="info-row"><span>动态图集 / 图集可读 / 内嵌源字体</span><span>${tri(f.dynamic)} / ${tri(f.atlasReadable)} / ${tri(f.sourceFontEmbedded)}</span>` +
          `</div><div class="info-row"><span>动态补字静态条件</span><span>${f.dynamicConditionsMet ? '已具备，运行效果待验证' : '未齐备或无法确定'}</span>` +
          `</div></div>`,
      )
      .join('')}${(report.warnings || []).map((w) => notice(esc(w), 'warning')).join('')}<p class="tiny subtle">` +
    `${esc(report.scope)}</p>` +
    `</details>`
  );
}
function migrationMarkup(m) {
  if (!m) return '';
  return (
    `<details class="font-report" open><summary>已有 XUnity 环境与译文缓存</summary><p class="tiny mono">${esc(m.loader)}<br>` +
    `${esc(m.translator)}</p>` +
    `${
      m.configFound
        ? `<div class="info-list">${Object.entries(m.fontValues || {})
            .map(
              ([key, value]) =>
                `<div class="info-row"><span>${esc(key)}</span><span class="mono tiny">${esc(value || '未设置')}</span>` +
                `</div>`,
            )
            .join(
              '',
            )}<div class="info-row"><span>旧译文语言 / 文件数</span><span>${esc(m.targetLanguage)} / ${number(m.cacheFileCount)}</span>` +
          `</div><div class="info-row"><span>旧缓存目录</span><span class="mono tiny">${esc(m.cacheDirectory)}</span>` +
          `</div></div>`
        : ''
    }${(m.notes || []).map((n) => `<p class="tiny subtle">${esc(n)}</p>`).join('')}${(m.conflicts || []).map((n) => notice(esc(n), 'warning')).join('')}${(m.tmpFonts || []).map(tmpReportMarkup).join('')}</details>`
  );
}
function fontCard(g) {
  const supported = fontSupported(g);
  return (
    `<section class="card font-card"><div class="card-header"><div><h2>${icon('edit')}替换字体</h2><p>为这个游戏单独选择文字字体。</p>` +
    `</div></div><div class="font-current"><small>当前设置</small><strong>${esc(fontSummary(g))}</strong>` +
    `</div><p class="card-description">${supported ? (g.engine === 'Unreal Engine' ? '使用游戏内 Font 资源，作用于适配器回填的文字。' : '适配器加载所选字体，具体控件和字符覆盖需在游戏中验证。') : g.capability === 'experimental-hook' ? '浮窗与内嵌字体在“Galgame 文本 Hook → 字体与显示”中设置。' : '此引擎尚未提供字体适配。'}</p>` +
    `${tmpReportMarkup(g.font?.tmpReport)}<div class="adapter-actions">` +
    `${
      g.engine === 'Unity'
        ? `<button class="btn" data-action="legacy-cache" data-id="${esc(g.id)}" ${g.adapterStatus === 'installed' ? 'disabled' : ''}>` +
          `${icon('folder')}旧译文缓存</button>`
        : ''
    }<button class="btn" data-action="game-font" data-id="${esc(g.id)}" ${supported ? '' : 'disabled'}>` +
    `${icon('edit')}替换字体</button>` +
    `</div></section>`
  );
}
async function showGameFont(id) {
  const g = gameById(id),
    info = await api(`/api/games/${encodeURIComponent(id)}/font`),
    font = info.settings || {};
  if (!info.supported) {
    toast('此引擎尚未提供字体适配', 'info');
    return;
  }
  const unity = g.engine === 'Unity',
    unreal = g.engine === 'Unreal Engine';
  const description = unity
    ? '普通 UI 使用系统字体；TextMeshPro 可单独选择字体包。'
    : unreal
      ? '使用游戏内已经加载的 Font 资源，暂不支持直接导入 TTF/OTF。'
      : '支持导入 TTF/OTF，保存时复制到工具数据目录。';
  const custom = unity
    ? `<label class="field">系统字体<input name="family" list="system-fonts" value="${esc(font.family || 'Microsoft YaHei')}" maxlength="128">` +
      `<datalist id="system-fonts">${(info.systemFonts || [])
        .map((name) => `<option value="${esc(name)}">` + `</option>`)
        .join('')}</datalist>` +
      `<small>输入字体名称或从本机已安装字体中选择。作用于 Unity UGUI。</small></label><label class="field">TMP 字体包（可选）<div class="inline-input">` +
      `<input name="filePath" id="font-file-path" placeholder="选择与游戏 Unity/TMP 版本匹配的 AssetBundle"><button type="button" class="btn" data-action="pick-font" data-id="${esc(id)}">` +
      `${icon('folder')}选择</button>` +
      `</div><small>${font.fileName ? '已保存：' + esc(font.fileName) + '。留空继续使用；点击移除可只替换系统字体。' : '留空只替换系统字体。普通 TTF/OTF 不能直接作为 TMP 字体包。'}</small>` +
      `${font.fileId ? '<label class="font-clear"><input name="clearFile" type="checkbox">移除已保存的 TMP 字体包</label>' : ''}</label>` +
      `<label class="field">TMP 字体用途<select name="tmpMode"><option value="fallback" ${font.tmpMode !== 'override' ? 'selected' : ''}>` +
      `后备字体：补充缺少的字符（推荐）</option><option value="override" ${font.tmpMode === 'override' ? 'selected' : ''}>` +
      `替换字体：统一字形</option></select></label>`
    : unreal
      ? `<label class="field">字体资源路径<input name="unrealPath" value="${esc(font.unrealPath || '/Engine/EngineFonts/Roboto.Roboto')}" placeholder="/Game/Fonts/MyFont.MyFont">` +
        `<small>填写游戏现有的 Font 对象路径。资源必须已被游戏加载，未找到时保留原字体。</small></label><label class="field">字形名称<input name="unrealTypeface" value="${esc(font.unrealTypeface || 'Regular')}" maxlength="64">` +
        `<small>通常为 Regular，需要与字体资源中的名称一致。</small></label>`
      : `<label class="field">字体文件（TTF / OTF）<div class="inline-input"><input name="filePath" id="font-file-path" placeholder="选择字体，或粘贴完整路径">` +
        `<button type="button" class="btn" data-action="pick-font" data-id="${esc(id)}">` +
        `${icon('folder')}选择</button>` +
        `</div><small>${font.fileName ? '已保存：' + esc(font.fileName) + '。留空继续使用。' : '选择包含目标语言字符的字体，文件最大 64 MB。'}</small>` +
        `</label>`;
  modal(
    '替换字体',
    esc(g.name),
    `<form id="game-font-form"><p class="card-description">${description}</p><label class="field">字体模式<select name="mode">` +
      `<option value="auto" ${!font.mode || font.mode === 'auto' ? 'selected' : ''}>` +
      `自动中文字体</option><option value="original" ${font.mode === 'original' ? 'selected' : ''}>` +
      `使用游戏原字体（关闭替换）</option><option value="custom" ${font.mode === 'custom' ? 'selected' : ''}>` +
      `自定义字体</option>${
        unity && info.migration?.available
          ? `<option value="existing" ${font.mode === 'existing' ? 'selected' : ''}>` +
            `沿用已有 XUnity 字体配置</option>`
          : ''
      }</select>` +
      `</label><div id="existing-font-fields">${migrationMarkup(info.migration)}</div>` +
      `<div id="custom-font-fields">${custom}${
        unity
          ? `<button type="button" class="btn small" data-action="inspect-font" data-id="${esc(id)}">` +
            `${icon('search')}检查字体包</button>` +
            `<div id="font-inspection">${tmpReportMarkup(font.tmpReport)}</div>` +
            `<div class="section-gap">${notice('统一替换 TMP 可能让原文中的日文缺字，等待翻译时也会出现方框。建议先用后备字体补字。', 'warning')}</div>`
          : ''
      }</div>` +
      `${notice(info.installed ? '请先关闭游戏。保存后直接更新已安装适配，重新启动游戏生效；卸载适配可恢复原始文件。' : '设置会在安装适配时生效。恢复自动可回到工具默认字体；保留原字体会关闭工具的字体替换。')}<p id="game-font-error" class="field-error" role="alert">` +
      `</p><div class="form-actions"><button class="btn" type="button" id="font-auto">${icon('refresh')}恢复自动</button>` +
      `<button class="btn" type="button" data-action="close-modal">取消</button><button class="btn primary" type="submit">` +
      `${icon('save')}${info.installed ? '保存并应用' : '保存字体设置'}</button>` +
      `</div></form>`,
  );
  const f = document.getElementById('game-font-form');
  function updateMode() {
    const custom = f.elements.mode.value === 'custom';
    document.getElementById('existing-font-fields').hidden = f.elements.mode.value !== 'existing';
    document.getElementById('custom-font-fields').hidden = !custom;
    document
      .querySelectorAll('#custom-font-fields input,#custom-font-fields select,#custom-font-fields button')
      .forEach((el) => (el.disabled = !custom));
    if (f.elements.family) f.elements.family.required = custom;
    if (f.elements.unrealPath) f.elements.unrealPath.required = custom;
    if (f.elements.unrealTypeface) f.elements.unrealTypeface.required = custom;
  }
  f.elements.mode.onchange = updateMode;
  updateMode();
  document.getElementById('font-auto').onclick = () => {
    f.elements.mode.value = 'auto';
    updateMode();
    modalDirty = true;
  };
  f.onsubmit = (e) => {
    e.preventDefault();
    const settings = { ...font, mode: f.elements.mode.value };
    if (unity) {
      settings.family = f.elements.family.value.trim();
      settings.tmpMode = f.elements.tmpMode.value;
      if (f.elements.clearFile?.checked) {
        settings.fileId = null;
        settings.fileName = null;
      }
    }
    if (unreal) {
      settings.unrealPath = f.elements.unrealPath.value.trim();
      settings.unrealTypeface = f.elements.unrealTypeface.value.trim();
    }
    const filePath = settings.mode === 'custom' ? f.elements.filePath?.value.trim() : undefined;
    document.getElementById('game-font-error').textContent = '';
    busy(f.querySelector('[type=submit]'), async () => {
      try {
        const result = await api(`/api/games/${encodeURIComponent(id)}/font`, {
          method: 'PUT',
          body: { settings, filePath },
        });
        closeModal(true);
        await refreshBootstrap();
        if (state.route === 'game' && state.gameId === id) renderGame();
        toast(result.applied ? '字体已应用，重新启动游戏后生效' : '字体设置已保存，安装适配时生效');
      } catch (error) {
        document.getElementById('game-font-error').textContent = error.message;
        throw error;
      }
    });
  };
}
function renderAi() {
  const stats = state.stats;
  const provider = providerById(state.settings.providerId);
  const enabled = state.settings.enabled !== false;
  main.innerHTML =
    `${pageHead(
      'AI 翻译',
      '把游戏文字连接到你选择的模型服务。',
      `<button class="btn" data-action="hook-stop-all">` +
        `${icon('close')}断开所有 Hook 连接</button>` +
        `<button class="btn" data-action="translate-test">${icon('send')}手动试译</button>` +
        `<button class="btn primary" data-action="add-provider">${icon('plus')}添加翻译服务</button>`,
      'YOUR TRANSLATION SERVICE',
    )}<div class="stats-grid">` +
    `${statsCard('已完成翻译', number(stats.completed), 'translate', 'green', 'completed')}${statsCard('缓存命中', number(stats.cacheHits), 'cache', 'purple', 'cacheHits')}${statsCard('正在处理 / 排队', `${number(stats.inFlight)} / ${number(stats.queued)}`, 'activity', '', 'queuePair')}${statsCard('最近请求耗时', typeof stats.lastElapsedMs === 'number' ? `${(stats.lastElapsedMs / 1000).toFixed(2)} s` : '—', 'clock', 'orange', 'lastElapsedMs')}</div>` +
    `<div class="status-card"><div class="status-orb ${enabled ? '' : 'paused'}">` +
    `${icon(enabled ? 'activity' : 'pause')}</div>` +
    `<div class="status-copy"><h3>${enabled ? '按需翻译已启用' : '翻译已暂停'}</h3>` +
    `<p>${provider ? `${esc(provider.name)} · ${esc(provider.model || '未设置模型')} · ${esc(state.settings.targetLanguage || 'zh-CN')}` : '先添加翻译服务，再选择当前使用的模型。'}<br>` +
    `已取得的文字按需翻译；支持预读时提前准备后续台词，缓存命中直接显示。</p></div><button class="btn ${enabled ? '' : 'primary'}" data-action="toggle-translation">` +
    `${icon(enabled ? 'pause' : 'play')}${enabled ? '暂停翻译' : '启用翻译'}</button>` +
    `</div><div class="grid-two"><section class="card"><div class="card-header"><div><h2>${icon('translate')}翻译配置</h2>` +
    `<p>游戏可以单独覆盖服务与语言。</p></div></div><form id="ai-settings"><label class="field">当前翻译服务<select name="providerId">${providerOptions(state.settings.providerId)}</select>` +
    `</label><div class="field-row"><label class="field">原文语言<select name="sourceLanguage">${languageOptions(state.settings.sourceLanguage, true)}</select>` +
    `</label><label class="field">目标语言<select name="targetLanguage">${languageOptions(state.settings.targetLanguage)}</select>` +
    `</label></div><label class="field">并发请求<input name="concurrency" type="number" min="1" max="8" value="${esc(state.settings.concurrency || 2)}">` +
    `<small>较高并发可能触发服务限流。默认同时处理 2 个请求。</small></label><label class="prefetch-setting"><input name="prefetchEnabled" type="checkbox" ${state.settings.prefetchEnabled !== false ? 'checked' : ''}>` +
    `<span><strong>能预读时提前翻译后续对白</strong><small>支持已适配的 Viewer 和标准 RPG Maker 对话；其他路线继续实时翻译。可能产生未播放台词的 API 用量。</small>` +
    `</span></label><label class="field">预读句数<input name="prefetchLines" type="number" min="1" max="10" step="1" required value="${Math.max(1, Math.min(10, Number(state.settings.prefetchLines) || 3))}" aria-label="预读句数">` +
    `<small>1–10 句，默认 3 句。实际数量受安全剧本边界和文字长度限制；预读越多，可能产生的 API 用量越大。旧游戏适配需关闭游戏后卸载重装一次。</small></label><div class="form-actions">` +
    `<button class="btn primary" type="submit">${icon('save')}保存配置</button>` +
    `</div></form></section><section class="card"><div class="card-header"><div><h2>${icon('book')}翻译提示词</h2>` +
    `<p>控制语气、格式和游戏文字的处理方式。</p></div></div><form id="prompt-settings"><label class="field">系统提示词<textarea name="prompt" rows="8" placeholder="使用默认游戏翻译提示词">` +
    `${esc(state.settings.prompt)}</textarea>` +
    `<small>支持占位符 {from}、{to}。保留原文中的变量、控制符和文本标签。</small></label><div class="form-actions"><button class="btn primary" type="submit">` +
    `${icon('save')}保存提示词</button>` +
    `</div></form></section></div><div class="subheading"><h2>翻译服务 <span class="inline-count">${state.providers.length} 个配置</span>` +
    `</h2><small>OpenAI 兼容 Chat Completions</small></div><div class="service-grid">${state.providers.map(providerCard).join('')}<button class="provider-add" data-action="add-provider">` +
    `${icon('plus')}<span>` +
    `添加自定义 API 服务</span></button></div><div class="section-gap">${notice('API Key 与每个服务绑定，保存在本机。测试连接、获取模型和手动试译由你主动触发；测试和试译会发送一次实际 API 请求。')}</div>`;
  document.getElementById('ai-settings').onsubmit = (e) => {
    e.preventDefault();
    const f = e.target,
      d = new FormData(f);
    busy(f.querySelector('[type=submit]'), () =>
      saveSettings(
        {
          providerId: d.get('providerId') || null,
          sourceLanguage: d.get('sourceLanguage'),
          targetLanguage: d.get('targetLanguage'),
          concurrency: Number(d.get('concurrency')),
          prefetchEnabled: d.get('prefetchEnabled') === 'on',
          prefetchLines: Number(d.get('prefetchLines')),
          prompt: document.getElementById('prompt-settings').elements.prompt.value,
        },
        '翻译配置已保存',
      ),
    );
  };
  document.getElementById('prompt-settings').onsubmit = (e) => {
    e.preventDefault();
    if (!document.getElementById('ai-settings').reportValidity()) return;
    const f = e.target;
    busy(f.querySelector('[type=submit]'), () =>
      saveSettings(
        {
          prompt: f.elements.prompt.value,
          providerId: document.getElementById('ai-settings').elements.providerId.value || null,
          sourceLanguage: document.getElementById('ai-settings').elements.sourceLanguage.value,
          targetLanguage: document.getElementById('ai-settings').elements.targetLanguage.value,
          concurrency: Number(document.getElementById('ai-settings').elements.concurrency.value),
          prefetchEnabled: document.getElementById('ai-settings').elements.prefetchEnabled.checked,
          prefetchLines: Number(document.getElementById('ai-settings').elements.prefetchLines.value),
        },
        '翻译配置与提示词已保存',
      ),
    );
  };
  markDirty('ai-settings');
  markDirty('prompt-settings');
}
function providerCard(p) {
  const selected = p.id === state.settings.providerId;
  return (
    `<section class="provider-card ${selected ? 'selected' : ''}"><div class="provider-top"><div class="provider-symbol">` +
    `${icon('ai')}</div>` +
    `<div><h3>${esc(p.name)}</h3>` +
    `<p>${p.hasKey ? '已保存 Key' : '无 API Key / 本地服务'}</p>` +
    `</div>${selected ? badge('当前服务', 'blue') : ''}</div>` +
    `<p class="provider-url mono">${esc(p.baseUrl)}</p>` +
    `<p class="provider-model">${icon('plug')}<span>` +
    `${esc(p.model || '未填写模型')}</span>` +
    `</p><div class="provider-actions"><button class="btn small" data-action="test-provider" data-id="${esc(p.id)}">` +
    `${icon('activity')}测试</button>` +
    `${
      !selected
        ? `<button class="btn small" data-action="select-provider" data-id="${esc(p.id)}">` + `设为当前</button>`
        : ''
    }<button class="btn small ghost" data-action="edit-provider" data-id="${esc(p.id)}">` +
    `${icon('edit')}编辑</button>` +
    `</div></section>`
  );
}
async function saveSettings(patch, message = '设置已保存') {
  await api('/api/settings', { method: 'PUT', body: patch });
  state.dirty = false;
  await refreshBootstrap();
  await render();
  toast(message);
}
function dataPageHead(title, description, actions = '') {
  const g = currentGame();
  return (
    `${
      g ? `<a class="back-link" href="#game/${encodeURIComponent(g.id)}">${icon('back')}返回 ${esc(g.name)}</a>` : ''
    }${pageHead(title, description, actions)}<div class="toolbar">` +
    `<div class="filter-select"><select id="data-game" aria-label="选择游戏">${gameOptions(state.gameId)}</select>` +
    `</div>`
  );
}
async function renderTranslations(sequence = renderSequence) {
  const query = new URLSearchParams({
    gameId: state.gameId,
    q: state.translationQuery,
    page: String(state.translationPage),
  });
  const data = await api(`/api/translations?${query}`);
  if (sequence !== renderSequence) return;
  const items = listItems(data),
    total = data?.total ?? items.length,
    pageSize = data?.pageSize || 50;
  main.innerHTML =
    `${dataPageHead(
      '译文编辑器',
      '查看模型译文、修订表达，并将结果存入本地缓存。',
      `<button class="btn" data-action="translate-test">` + `${icon('send')}手动试译</button>`,
    )}<div class="search-field">` +
    `<input id="translation-search" aria-label="搜索原文和译文" placeholder="搜索原文或译文" value="${esc(state.translationQuery)}">` +
    `</div><div class="toolbar-end"><small class="muted">${total} 条记录</small>` +
    `<button class="btn" data-action="refresh-page">${icon('refresh')}刷新</button>` +
    `</div></div>${
      items.length
        ? `<div class="table-wrap">` +
          `<table><thead><tr><th style="width:42%">原文</th><th style="width:42%">译文</th><th>来源 / 时间</th><th>操作</th></tr></thead>` +
          `<tbody>${items
            .map(
              (t) =>
                `<tr>` +
                `<td><div class="text-cell muted">${esc(t.source)}</div>` +
                `${
                  !state.gameId && t.gameId
                    ? `<small class="subtle">` + `${esc(gameById(t.gameId)?.name || '已移除的游戏')}</small>`
                    : ''
                }</td>` +
                `<td><div class="text-cell">${esc(t.translation)}</div>` +
                `</td><td>${badge(t.manual ? '人工修订' : '模型生成', t.manual ? 'green' : '')}<div class="subtle tiny section-gap">` +
                `${esc(t.model || '—')}<br>` +
                `${esc(dateText(t.updatedAt || t.createdAt))}</div>` +
                `</td><td><div class="table-actions"><button class="icon-button" data-action="edit-translation" data-id="${esc(t.id)}" title="编辑译文" aria-label="编辑译文">` +
                `${icon('edit')}</button>` +
                `<button class="icon-button" data-action="delete-translation" data-id="${esc(t.id)}" title="删除缓存" aria-label="删除缓存">` +
                `${icon('trash')}</button>` +
                `</div></td></tr>`,
            )
            .join('')}</tbody>` +
          `</table></div><div class="pagination"><span>第 ${state.translationPage} 页 · 共 ${total} 条</span>` +
          `<div class="actions"><button class="btn small" data-action="translation-page" data-value="${state.translationPage - 1}" ${state.translationPage <= 1 ? 'disabled' : ''}>` +
          `${icon('back')}上一页</button>` +
          `<button class="btn small" data-action="translation-page" data-value="${state.translationPage + 1}" ${state.translationPage * pageSize >= total ? 'disabled' : ''}>` +
          `下一页${icon('arrow')}</button>` +
          `</div></div>`
        : empty(
            '这里会留下每一次翻译',
            '游戏取词翻译或手动试译后，可在这里查看记录，并修订不合适的译法。',
            '',
            'translate',
          )
    }<div class="section-gap">` +
    `${notice('人工修订更新工具服务缓存；删除只清除该条服务缓存。Ren’Py / RPG Maker 需重启游戏刷新进程缓存；Unity 还需备份并处理 XUnity 自身的译文缓存，再验证游戏中的新译文。')}</div>`;
  main._translationItems = items;
  bindDataGame('translations');
  document.getElementById('translation-search').oninput = debounce((e) => {
    state.translationQuery = e.target.value;
    state.translationPage = 1;
    renderPreservingInput('translation-search', () => renderTranslations());
  }, 250);
}
async function renderGlossary(sequence = renderSequence) {
  const data = await api(`/api/glossary?${new URLSearchParams({ gameId: state.gameId })}`);
  if (sequence !== renderSequence) return;
  const all = listItems(data),
    items = all.filter((t) =>
      `${t.source} ${t.target} ${t.note}`.toLowerCase().includes(state.glossaryQuery.toLowerCase()),
    );
  main.innerHTML =
    `${dataPageHead(
      '游戏词表',
      '把人名、地名和重要术语，保持为你认可的译法。',
      `<button class="btn primary" data-action="add-term">` + `${icon('plus')}添加词条</button>`,
    )}<div class="search-field">` +
    `<input id="glossary-search" aria-label="搜索词条" placeholder="搜索原词、译法或备注" value="${esc(state.glossaryQuery)}">` +
    `</div><div class="toolbar-end"><small class="muted">${all.length} 个词条</small>` +
    `</div></div>${
      items.length
        ? `<div class="table-wrap">` +
          `<table><thead><tr><th>原词</th><th>固定译法</th><th>所属游戏</th><th>备注</th><th>操作</th></tr></thead><tbody>${items
            .map(
              (t) =>
                `<tr>` +
                `<td><div class="text-cell">${esc(t.source)}</div>` +
                `</td><td><div class="text-cell">${esc(t.target)}</div>` +
                `</td><td><span class="muted tiny">${esc(t.gameId ? gameById(t.gameId)?.name || '已移除的游戏' : '全局词条')}</span>` +
                `</td><td><div class="text-cell muted">${esc(t.note)}</div>` +
                `</td><td><div class="table-actions"><button class="icon-button" data-action="edit-term" data-id="${esc(t.id)}" aria-label="编辑词条" title="编辑词条">` +
                `${icon('edit')}</button>` +
                `<button class="icon-button" data-action="delete-term" data-id="${esc(t.id)}" aria-label="删除词条" title="删除词条">` +
                `${icon('trash')}</button>` +
                `</div></td></tr>`,
            )
            .join('')}</tbody>` +
          `</table></div>`
        : empty(
            state.glossaryQuery ? '没有找到词条' : '为故事准备一份词表',
            state.glossaryQuery ? '换个关键词试试。' : '添加固定译法，在后续翻译中统一人名、物品和常用术语。',
            !state.glossaryQuery
              ? `<button class="btn primary" data-action="add-term">` + `${icon('plus')}添加第一个词条</button>`
              : '',
            'book',
          )
    }<div class="section-gap">` +
    `${notice('游戏词条优先于全局词条。已有缓存不会因为修改词表而自动改写，相关译文可以在编辑器中修订或删除后重新翻译。')}</div>`;
  main._glossaryItems = all;
  bindDataGame('glossary');
  document.getElementById('glossary-search').oninput = debounce((e) => {
    state.glossaryQuery = e.target.value;
    renderPreservingInput('glossary-search', () => renderGlossary());
  }, 200);
}
function bindDataGame(route) {
  document.getElementById('data-game').onchange = (e) => {
    state.translationPage = 1;
    location.hash = `${route}${e.target.value ? '/' + encodeURIComponent(e.target.value) : ''}`;
  };
}
async function renderPreservingInput(id, fn) {
  const el = document.getElementById(id),
    position = el?.selectionStart;
  await fn();
  const next = document.getElementById(id);
  if (next) {
    next.focus();
    try {
      next.setSelectionRange(position, position);
    } catch {}
  }
}
const diagnosticReports = {};
function diagnosticMarkup(report) {
  if (!report) return '';
  const r = report.runtime || {};
  return (
    `<section class="card diagnostic-report"><div class="card-header"><div><h2>${icon('activity')}诊断摘要</h2>` +
    `<p>${esc(report.summary)}</p>` +
    `</div></div><div class="runtime-counts">${[
      ['收到原文', r.received],
      ['获得译文', r.translated],
      ['响应已发送', r.delivered],
      ['绘制 / 回读证据', `${number(r.pluginApplied)} / ${number(r.pluginVerified)}`],
    ]
      .map(
        ([label, value]) =>
          `<div><strong>${typeof value === 'string' ? esc(value) : number(value)}</strong><small>${esc(label)}</small>` +
          `</div>`,
      )
      .join('')}</div><p class="tiny subtle">${esc(report.visualStatus)}</p>${(report.issues || [])
      .map(
        (issue) =>
          `<details class="diagnostic-issue" ${issue.scope === 'current' ? 'open' : ''}>` +
          `<summary>${badge(issue.scope === 'current' ? '本次 / 当前' : '历史记录', issue.scope === 'current' ? 'blue' : '')}${esc(issue.title)}${issue.count > 1 ? ` · ${number(issue.count)} 条` : ''}</summary>` +
          `<p>${esc(issue.suggestion)}</p>` +
          `${(issue.evidence || [])
            .map(
              (e) =>
                `<small>` +
                `${esc(e.source)} · ${esc(dateText(e.time))} · ${esc(e.timeBasis)}</small>` +
                `<pre>${esc(e.message)}</pre>`,
            )
            .join('')}</details>`,
      )
      .join('')}<details class="diagnostic-sources">` +
    `<summary>日志来源与读取状态</summary>${(report.sources || [])
      .map(
        (source) =>
          `<div class="diagnostic-source">` +
          `<strong>${esc(source.name)} · ${esc({ read: '已读取', missing: '尚未生成', unknown: '路径未知', denied: '没有权限', unreadable: '无法读取', reported: '当前上报', stale: '上次上报' }[source.state] || source.state)}</strong>` +
          `<code>${esc(source.path || '未关联')}</code>` +
          `<small>${esc(source.note)}${source.modifiedAt ? ' · ' + esc(dateText(source.modifiedAt)) : ''}</small>` +
          `</div>`,
      )
      .join('')}</details>` +
    `${(report.notes || []).map((n) => `<p class="tiny subtle">` + `${esc(n)}</p>`).join('')}<div class="actions">` +
    `<button class="btn small" data-action="copy-diagnostics" data-id="${esc(report.gameId)}">` +
    `复制诊断</button><button class="btn small" data-action="export-diagnostics" data-id="${esc(report.gameId)}">` +
    `导出脱敏报告</button>${
      gameById(report.gameId)?.engine === 'Unity'
        ? `<button class="btn small" data-action="player-log" data-id="${esc(report.gameId)}">` +
          `关联 Player.log</button>`
        : ''
    }</div>` +
    `</section>`
  );
}
async function showPlayerLog(id) {
  const g = gameById(id);
  modal(
    '关联 Player.log',
    esc(g.name),
    `<form id="player-log-form"><p class="card-description">通过工具启动会自动使用专属日志。若从其他位置启动游戏，可手动关联该游戏的默认 Player.log；现有内容标为历史记录。</p>` +
      `<label class="field">日志路径<div class="inline-input"><input name="path" id="player-log-path" value="${esc(g.playerLogPath || '')}" placeholder="此游戏的 Player.log">` +
      `<button class="btn" type="button" data-action="pick-player-log" data-id="${esc(id)}">` +
      `选择</button></div><small>留空取消关联。只读取日志，不改写所选文件。</small></label><div class="form-actions"><button class="btn" type="button" data-action="close-modal">` +
      `取消</button><button class="btn primary" type="submit">保存关联</button></div></form>`,
  );
  const f = document.getElementById('player-log-form');
  f.onsubmit = (e) => {
    e.preventDefault();
    busy(f.querySelector('[type=submit]'), async () => {
      await api(`/api/games/${encodeURIComponent(id)}/player-log`, {
        method: 'PUT',
        body: { path: f.elements.path.value.trim() },
      });
      closeModal(true);
      await refreshBootstrap();
      await renderLogs();
      toast('日志关联已保存');
    });
  };
}
async function renderLogs(sequence = renderSequence, contentOnly = false) {
  const gameId = state.gameId || state.logs.gameId,
    query = new URLSearchParams({
      level: state.logs.level || '',
      q: state.logs.q || '',
      source: state.logs.module || '',
      scope: state.logs.scope || '',
    });
  const report = gameId ? await api(`/api/games/${encodeURIComponent(gameId)}/diagnostics?${query}`) : null;
  const data = report
    ? report.entries
    : await api(
        `/api/logs?${new URLSearchParams({ level: state.logs.level || '', q: state.logs.q || '', module: state.logs.module || '' })}`,
      );
  if (sequence !== renderSequence || state.route !== 'logs') return;
  if (report) diagnosticReports[gameId] = report;
  const items = listItems(data);
  const content =
    (report ? diagnosticMarkup(report) : '') +
    (items.length
      ? `<div class="log-list">${items
          .map(
            (l) =>
              `<div class="log-entry"><time class="log-time" title="${esc(l.timeBasis || '日志记录时间')}">` +
              `${esc(dateText(l.time || l.createdAt))}${
                report ? `<small>` + `${l.scope === 'current' ? '本次启动' : '历史记录'}</small>` : ''
              }</time>` +
              `<span class="log-level ${esc(String(l.level || 'info').toLowerCase())}">` +
              `${esc(String(l.level || 'info').toUpperCase())}</span>` +
              `<span class="log-module">${esc(l.source || l.module || '系统')}${
                l.gameId ? `<br>` + `<small class="subtle">${esc(gameById(l.gameId)?.name || '游戏')}</small>` : ''
              }</span>` +
              `<div class="log-message">${esc(l.message)}</div>` +
              `${
                l.details
                  ? `<details>` +
                    `<summary>查看详情${l.requestId ? ` · ${esc(l.requestId)}` : ''}</summary>` +
                    `<pre>${esc(typeof l.details === 'string' ? l.details : JSON.stringify(l.details, null, 2))}</pre>` +
                    `</details>`
                  : ''
              }${
                l.path
                  ? `<details>` +
                    `<summary>来源文件</summary><code>${esc(l.path)}</code>` +
                    `<p class="tiny">${esc(l.timeBasis)}</p>` +
                    `</details>`
                  : ''
              }</div>`,
          )
          .join('')}</div>`
      : empty('当前筛选没有日志', '启动游戏后刷新，或调整来源、级别和搜索条件。', '', 'logs'));
  if (contentOnly) {
    const holder = document.getElementById('log-content');
    if (holder) holder.innerHTML = content;
    const time = document.getElementById('log-updated');
    if (time) time.textContent = new Date().toLocaleTimeString('zh-CN', { hour12: false });
    return;
  }
  main.innerHTML =
    `${pageHead(
      '运行日志',
      '按游戏汇总工具、适配器与引擎日志；本次启动和历史记录分别标记。',
      `<button class="btn" data-action="${gameId ? 'export-diagnostics' : 'export-logs'}" data-id="${esc(gameId || '')}">` +
        `${icon('download')}${gameId ? '导出诊断报告' : '导出工具日志'}</button>` +
        `<button class="btn" data-action="refresh-logs">${icon('refresh')}刷新</button>`,
    )}<div class="toolbar log-toolbar">` +
    `<div class="filter-select"><select id="log-game" aria-label="按游戏筛选">${gameOptions(gameId)}</select>` +
    `</div><div class="filter-select"><select id="log-level" aria-label="按日志级别筛选"><option value="">全部级别</option>${[
      'info',
      'warning',
      'error',
      'debug',
    ]
      .map((v) => `<option value="${v}" ${state.logs.level === v ? 'selected' : ''}>` + `${v.toUpperCase()}</option>`)
      .join('')}</select>` +
    `</div><div class="filter-select"><input id="log-module" placeholder="${gameId ? '来源，例如 Player.log' : '模块名称'}" aria-label="按日志来源筛选" value="${esc(state.logs.module || '')}">` +
    `</div>${
      gameId
        ? `<div class="filter-select">` +
          `<select id="log-scope" aria-label="按启动范围筛选"><option value="">本次与历史</option><option value="current" ${state.logs.scope === 'current' ? 'selected' : ''}>` +
          `本次启动</option><option value="historical" ${state.logs.scope === 'historical' ? 'selected' : ''}>` +
          `历史记录</option></select></div>`
        : ''
    }<div class="search-field">` +
    `<input id="log-search" placeholder="搜索日志内容" aria-label="搜索日志内容" value="${esc(state.logs.q || '')}">` +
    `</div></div><div class="card-header"><div class="status-summary"><span class="status-dot ${state.logs.auto ? '' : 'paused'}">` +
    `</span>${state.logs.auto ? '每 5 秒刷新' : '自动刷新已暂停'}<span>` +
    `· 更新于 <span id="log-updated">${esc(new Date().toLocaleTimeString('zh-CN', { hour12: false }))}</span>` +
    `</span></div><button class="btn small ghost" data-action="toggle-log-auto">${icon(state.logs.auto ? 'pause' : 'play')}${state.logs.auto ? '暂停刷新' : '自动刷新'}</button>` +
    `</div><div id="log-content">${content}</div>` +
    `<p class="tiny subtle section-gap">已对密钥及常见凭据格式脱敏；文本与路径仍可能出现于诊断中。</p>`;
  document.getElementById('log-game').onchange = (e) => {
    state.logs.gameId = e.target.value;
    location.hash = `logs${e.target.value ? '/' + encodeURIComponent(e.target.value) : ''}`;
    if (!e.target.value && state.route === 'logs' && !state.gameId) renderLogs();
  };
  document.getElementById('log-level').onchange = (e) => {
    state.logs.level = e.target.value;
    renderLogs();
  };
  document.getElementById('log-module').oninput = debounce((e) => {
    state.logs.module = e.target.value;
    renderPreservingInput('log-module', () => renderLogs());
  }, 250);
  document.getElementById('log-search').oninput = debounce((e) => {
    state.logs.q = e.target.value;
    renderPreservingInput('log-search', () => renderLogs());
  }, 250);
  if (document.getElementById('log-scope'))
    document.getElementById('log-scope').onchange = (e) => {
      state.logs.scope = e.target.value;
      renderLogs();
    };
}
let logPolling = false;
setInterval(async () => {
  if (
    state.route !== 'logs' ||
    !state.logs.auto ||
    document.hidden ||
    logPolling ||
    document.getElementById('modal-root').childElementCount
  )
    return;
  logPolling = true;
  try {
    await renderLogs(renderSequence, true);
  } catch {
  } finally {
    logPolling = false;
  }
}, 5000);
let statsPolling = false;
setInterval(async () => {
  if (state.route !== 'ai' || document.hidden || statsPolling) return;
  statsPolling = true;
  try {
    const stats = await api('/api/stats');
    state.stats = { ...state.stats, ...stats };
    document.querySelectorAll('[data-stat]').forEach((el) => {
      const key = el.dataset.stat;
      el.textContent =
        key === 'queuePair'
          ? `${number(stats.inFlight)} / ${number(stats.queued)}`
          : key === 'lastElapsedMs'
            ? typeof stats.lastElapsedMs === 'number'
              ? `${(stats.lastElapsedMs / 1000).toFixed(2)} s`
              : '—'
            : number(stats[key]);
    });
  } catch {
  } finally {
    statsPolling = false;
  }
}, 3000);
async function renderSettings(sequence = renderSequence) {
  const [diagnostics, updates] = await Promise.all([api('/api/diagnostics'), api('/api/updates/status')]);
  if (sequence !== renderSequence) return;
  state.diagnostics = diagnostics;
  const zoom = state.settings.zoom || 100;
  main.innerHTML =
    `${pageHead('设置', '让工作空间适合你的阅读习惯。')}<div class="grid-two"><div class="stack"><section class="card">` +
    `<div class="card-header"><h2>${icon('sun')}外观</h2>` +
    `</div><form id="appearance-settings"><label class="field">界面主题</label><div class="theme-options">${[
      ['light', 'sun', '浅色'],
      ['dark', 'moon', '深色'],
      ['system', 'monitor', '跟随系统'],
    ]
      .map(
        ([v, i, l]) =>
          `<button type="button" class="theme-option ${state.settings.theme === v ? 'active' : ''}" data-action="select-theme" data-value="${v}">` +
          `${icon(i)}${l}</button>`,
      )
      .join(
        '',
      )}</div><div class="setting-line"><div><strong>主题色</strong><small>用于按钮与当前页面的强调</small></div><input type="color" name="accent" value="${esc(state.settings.accent || '#8063c5')}" aria-label="主题色">` +
    `</div><div class="setting-line"><div><strong>界面缩放</strong><small id="zoom-value">${esc(zoom)}%</small>` +
    `</div><input type="range" name="zoom" min="80" max="130" step="5" value="${esc(zoom)}" aria-label="界面缩放">` +
    `</div><div class="form-actions"><button class="btn primary" type="submit">${icon('save')}保存外观</button>` +
    `</div></form></section><section class="card"><div class="card-header"><h2>${icon('shield')}API Key 与隐私</h2>` +
    `</div><p class="card-description">密钥使用 ${esc(diagnostics.apiKeyStorage || '本机安全存储')} 保存。编辑已有服务时不回显原密钥；日志与数据备份不包含密钥。</p>` +
    `<div class="section-gap">${notice('翻译只发送原文、必要上下文与词表到你选择的服务。服务配置在「AI 翻译」页面维护。')}</div>` +
    `<div class="form-actions"><a class="btn" href="#ai">${icon('ai')}管理翻译服务</a>` +
    `</div></section></div><div class="stack"><section class="card"><div class="card-header"><h2>${icon('folder')}本地数据</h2>` +
    `</div><p class="card-description">游戏库、译文、词表与设置保存在本机。</p><code class="data-path">${esc(diagnostics.dataDirectory || '由启动程序确定')}</code>` +
    `<div class="actions"><button class="btn" data-action="open-folder" data-kind="data">${icon('folder')}打开数据目录</button>` +
    `<button class="btn" data-action="export-data">${icon('download')}导出备份</button>` +
    `</div><div class="section-gap">${notice('导出的备份包括配置与翻译数据，不包含 API Key 和自定义请求头中的凭据。')}</div>` +
    `</section><section class="card"><div class="card-header"><h2>${icon('activity')}关于与适配能力</h2>` +
    `</div><div class="diagnostic-list"><div class="diagnostic-item"><small>应用版本</small><strong>${esc(diagnostics.version || state.version)}</strong>` +
    `</div><div class="diagnostic-item"><small>本机服务</small><strong>127.0.0.1:${esc(diagnostics.port || location.port)}</strong>` +
    `</div></div><div class="section-gap info-list">${(diagnostics.engines || [])
      .map(
        (e) =>
          `<div class="info-row">` +
          `<span>${esc(e.name)}</span>` +
          `<span>${badge(e.status || '待调查', String(e.status || '').includes('试验') ? 'blue' : '')}<small class="muted" style="display:block;margin-top:5px">` +
          `${esc(e.description)}</small>` +
          `</span></div>`,
      )
      .join('')}</div>` +
    `<div class="divider"></div><div class="actions"><button class="btn small" data-action="open-folder" data-kind="logs">` +
    `${icon('logs')}打开日志目录</button>` +
    `<a class="btn small" href="#logs">查看运行日志</a></div></section></div></div>`;
  main.querySelector('.grid-two > .stack:last-child').insertAdjacentHTML('afterbegin', localUpdateCard(updates));
  loadOnlineUpdates();
  document.getElementById('appearance-settings').onsubmit = (e) => {
    e.preventDefault();
    const f = e.target;
    busy(f.querySelector('[type=submit]'), () =>
      saveSettings({ accent: f.elements.accent.value, zoom: Number(f.elements.zoom.value) }, '外观设置已保存'),
    );
  };
  document.querySelector('[name=zoom]').oninput = (e) =>
    (document.getElementById('zoom-value').textContent = e.target.value + '%');
  markDirty('appearance-settings');
}
function localUpdateCard(updates) {
  const last = updates.lastResult;
  return (
    `<section class="card"><div class="card-header"><h2>${icon('download')}程序更新</h2>${badge(`v${updates.currentVersion || state.version}`, 'blue')}</div>` +
    `<div id="online-update-panel"><p class="card-description">正在读取更新状态…</p></div><details class="advanced"><summary>` +
    `本地更新包</summary><p class="card-description">已有专用更新 ZIP 时，可离线校验并安装。</p><div class="actions"><button class="btn" data-action="local-update">` +
    `${icon('folder')}选择本地更新包</button>` +
    `<a class="btn" href="#logs">${icon('logs')}更新日志</a>` +
    `</div></details>${
      last
        ? `<div class="update-last">` +
          `<strong>上次更新 · ${esc(last.fromVersion)} → ${esc(last.targetVersion)}</strong>` +
          `<p>${esc(last.message)}</p>` +
          `<small class="muted">${dateText(last.time)}</small>` +
          `</div>`
        : ''
    }${(updates.recovery || [])
      .map(
        (r) =>
          `<div class="section-gap">` +
          `${notice('上次有备份的更新尚未恢复完成。', 'warning')}<div class="actions">` +
          `<button class="btn" data-action="recover-update" data-id="${esc(r.id)}" data-version="${esc(r.currentVersion)}">` +
          `恢复 v${esc(r.currentVersion)}</button>` +
          `</div></div>`,
      )
      .join(
        '',
      )}${(updates.repair || []).length ? notice('上次更新未完成且没有旧程序备份，请重新解压完整程序包到原目录，保留 data。', 'warning') : ''}</section>`
  );
}
function updateSize(bytes) {
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}
function showLocalUpdate() {
  if (state.dirty) {
    toast('请先保存当前设置，再开始本地更新', 'info');
    return;
  }
  const context = { active: true, preview: null };
  const onClose = () => {
    context.active = false;
    if (context.preview && !state.updateInProgress)
      api('/api/updates/cancel', { method: 'POST', body: { id: context.preview.id } }).catch(errorToast);
  };
  modal(
    '本地更新',
    '选择 Rika Translator 专用 ZIP 更新包，校验后查看版本说明。',
    `<form id="local-update-form"><label class="field">更新包（ZIP）<div class="inline-input"><input id="update-path" name="path" placeholder="粘贴 ZIP 文件完整路径，或点击选择" required>` +
      `<button type="button" class="btn" data-action="pick-update">${icon('folder')}选择</button>` +
      `</div></label>${notice('请先关闭正在翻译的游戏。游戏适配组件保持现有安装状态。')}<div class="form-actions">` +
      `<button class="btn" type="button" data-action="close-modal">取消</button><button class="btn primary" type="submit">` +
      `${icon('check')}校验更新包</button>` +
      `</div></form>`,
    { onClose },
  );
  const content = document.querySelector('.modal-content');
  for (const type of ['input', 'change']) content.addEventListener(type, () => (modalDirty = false));
  document.getElementById('local-update-form').onsubmit = (e) => {
    e.preventDefault();
    const path = e.target.elements.path.value;
    busy(e.target.querySelector('[type=submit]'), async () => {
      const preview = await api('/api/updates/inspect', { method: 'POST', body: { path } });
      context.preview = preview;
      if (!context.active) {
        await api('/api/updates/cancel', { method: 'POST', body: { id: preview.id } });
        return;
      }
      modal(
        '确认本地更新',
        '更新包校验通过。请阅读说明，再确认安装。',
        `<div class="update-versions"><div><small>当前版本</small><strong>v${esc(preview.currentVersion)}</strong>` +
          `</div><span class="update-arrow" aria-hidden="true">→</span><div><small>更新版本</small><strong>v${esc(preview.targetVersion)}</strong>` +
          `</div></div><p class="tiny muted">Windows x64 · ${number(preview.fileCount)} 个文件 · 更新包 ${updateSize(preview.packageSize)} · 展开后 ${updateSize(preview.expandedSize)}</p>` +
          `<h3 class="update-notes-title">更新说明</h3><div class="update-notes">${esc(preview.releaseNotes)}</div>` +
          `${notice(preview.createBackup ? '工具会退出并备份旧程序，更新后检查能否启动；检查失败会恢复旧程序。' : '工具会退出并安装新版，检查启动后重新打开。保留个人数据，不创建旧程序备份。')}<div class="form-actions">` +
          `<button class="btn" data-action="close-modal">取消</button><button class="btn primary" data-action="install-local-update" data-id="${esc(preview.id)}">` +
          `${icon('download')}确认更新并重启</button>` +
          `</div>`,
        { onClose },
      );
    });
  };
}
function showUpdateRecovery(id, version) {
  if (state.dirty) {
    toast('请先保存当前设置，再恢复旧程序', 'info');
    return;
  }
  modal(
    '恢复旧程序',
    '恢复上次中断更新前的程序文件。',
    `${notice('请先关闭游戏。工具会退出，按校验记录恢复旧程序后重新打开；现有数据会保留。', 'warning')}<p>恢复版本：<strong>v${esc(version)}</strong></p>` +
      `<div class="form-actions"><button class="btn" data-action="close-modal">取消</button><button class="btn primary" data-action="install-local-update" data-id="${esc(id)}" data-restore="true">` +
      `确认恢复并重启</button></div>`,
  );
}
async function installLocalUpdate(id, restore) {
  const result = await api(restore ? '/api/updates/restore' : '/api/updates/install', {
    method: 'POST',
    body: { id, confirmed: true },
  });
  if (!result.scheduled) throw new Error('未能安排本地更新');
  state.updateInProgress = true;
  state.dirty = false;
  modalDirty = false;
  modal(
    '正在重新打开工具',
    '独立更新程序已就绪。',
    `<div class="page-loading"><span class="spinner"></span><p>${restore ? '正在恢复旧程序' : '正在退出并安装更新'}…</p></div>`,
  );
  document.querySelectorAll('button,input,select,textarea').forEach((el) => (el.disabled = true));
}
function markDirty(id) {
  document.getElementById(id)?.addEventListener('input', () => (state.dirty = true));
  document.getElementById(id)?.addEventListener('change', () => (state.dirty = true));
}
function debounce(fn, wait = 200) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}

let modalDirty = false,
  modalCloseHandler = null;
function modal(title, description, content, { wide = false, onClose } = {}) {
  const root = document.getElementById('modal-root');
  modalDirty = false;
  modalCloseHandler = onClose;
  root.innerHTML =
    `<div class="modal-backdrop"><section class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-labelledby="modal-title" tabindex="-1">` +
    `<div class="modal-head"><div><h2 id="modal-title">${esc(title)}</h2>` +
    `<p>${description}</p>` +
    `</div><button class="icon-button" data-action="close-modal" aria-label="关闭对话框">${icon('close')}</button>` +
    `</div><div class="modal-content">${content}</div>` +
    `</section></div>`;
  root.querySelector('.modal').focus();
  root.querySelector('.modal-content').addEventListener('input', () => (modalDirty = true));
  root.querySelector('.modal-content').addEventListener('change', () => (modalDirty = true));
  root.querySelector('.modal-backdrop').onclick = (e) => {
    if (e.target.classList.contains('modal-backdrop')) closeModal();
  };
}
function closeModal(force = false) {
  if (state.updateInProgress) return;
  if (!force && modalDirty && !confirm('当前内容尚未保存，确定关闭吗？')) return;
  document.getElementById('modal-root').innerHTML = '';
  modalDirty = false;
  const callback = modalCloseHandler;
  modalCloseHandler = null;
  if (callback) callback();
}
function showAddGame(path = '') {
  modal(
    '添加游戏',
    '选择游戏启动程序，检测引擎与可用适配。',
    `<form id="add-game-form"><label class="field">游戏启动程序（EXE）<div class="inline-input"><input name="path" id="game-path" placeholder="例如 F:\\Games\\MyGame\\Game.exe" value="${esc(path)}" required>` +
      `<button type="button" class="btn" data-action="pick-game">${icon('folder')}选择</button>` +
      `</div><small>可以粘贴完整路径，中文目录与空格均可使用。</small></label><label class="field">显示名称（可选）<input name="name" placeholder="留空时从程序名称读取">` +
      `</label><div class="actions"><button type="button" class="btn" data-action="inspect-game">${icon('search')}检测引擎</button>` +
      `</div><div id="game-detection"></div><div class="form-actions"><button class="btn" type="button" data-action="close-modal">` +
      `取消</button><button class="btn primary" type="submit">${icon('plus')}添加到游戏库</button>` +
      `</div></form>`,
  );
  document.getElementById('add-game-form').onsubmit = (e) => {
    e.preventDefault();
    const f = e.target,
      d = new FormData(f);
    busy(f.querySelector('[type=submit]'), async () => {
      const g = await api('/api/games', {
        method: 'POST',
        body: { path: d.get('path').trim(), name: d.get('name').trim() || undefined },
      });
      closeModal(true);
      await refreshBootstrap();
      location.hash = `game/${encodeURIComponent(g.id || g.game?.id)}`;
      toast('游戏已添加');
    });
  };
}
function showProvider(p = {}) {
  const existing = !!p.id;
  const headers = '';
  const body =
    typeof p.extraBody === 'object' && p.extraBody ? JSON.stringify(p.extraBody, null, 2) : p.extraBody || '';
  modal(
    existing ? '编辑翻译服务' : '添加翻译服务',
    '使用 OpenAI 兼容 Chat Completions 接口。',
    `<form id="provider-form"><div class="field-row"><label class="field">服务名称<input name="name" value="${esc(p.name)}" placeholder="例如 我的 DeepSeek" required maxlength="100">` +
      `</label><label class="field">接口预设<select id="provider-preset"><option value="custom">自定义接口</option><option value="openai">` +
      `OpenAI</option><option value="deepseek">DeepSeek</option><option value="local">本地服务</option></select></label></div>` +
      `<label class="field">Base URL / 完整端点<input name="baseUrl" type="url" value="${esc(p.baseUrl)}" placeholder="https://你的服务地址/v1" required>` +
      `<small>支持基础地址或完整的 /chat/completions 端点。</small></label><label class="field">API Key<input name="apiKey" type="password" autocomplete="new-password" spellcheck="false" placeholder="${existing && p.hasKey ? '已保存密钥；留空保留现有 Key' : '本地无鉴权服务可留空'}">` +
      `<small>${existing ? '不会显示已保存的密钥。输入新 Key 会替换旧值。' : '每个服务单独保存 Key，不与其他配置混用。'}</small>` +
      `</label>${existing && p.hasKey ? '<label class="check-row"><input type="checkbox" name="clearKey">清除已保存的 API Key（无鉴权服务）</label>' : ''}<label class="field">` +
      `模型 ID<div class="inline-input"><input name="model" value="${esc(p.model)}" placeholder="填写平台提供的模型 ID" required>` +
      `<button type="button" class="btn" data-action="provider-models" data-id="${esc(p.id || '')}">` +
      `${icon('refresh')}获取模型</button>` +
      `</div><small>模型 ID 是平台要求的接口标识，大小写、版本后缀需与平台一致，不是自定义显示名称。可先获取列表选择；平台不提供列表时手动填写。获取模型使用当前表单配置，无需先保存。</small><select id="provider-model-choice" aria-label="从返回的模型列表中选择" hidden>` +
      `</select><datalist id="provider-model-list"></datalist></label><details class="advanced"><summary>请求参数与兼容设置</summary>` +
      `<div><label class="check-row"><input type="checkbox" name="stream" ${p.stream ? 'checked' : ''}>` +
      `使用流式响应（SSE）</label><div class="field-row"><label class="field">Temperature（可留空）<input name="temperature" type="number" min="0" max="2" step="0.1" value="${p.temperature != null ? esc(p.temperature) : ''}" placeholder="由服务决定">` +
      `</label><label class="field">最大输出 Token（可留空）<input name="maxTokens" type="number" min="1" value="${p.maxTokens != null ? esc(p.maxTokens) : ''}" placeholder="不发送此参数">` +
      `</label></div><label class="field">超时（秒）<input name="timeoutSeconds" type="number" min="5" max="600" value="${esc(p.timeoutSeconds || 60)}">` +
      `</label><label class="field">额外请求头（JSON 对象）<textarea name="extraHeaders" class="mono" rows="3" placeholder="${existing ? '留空保留已保存的请求头' : '{}'}">` +
      `${esc(headers)}</textarea>` +
      `<small>已有请求头中的凭据不回显；留空保留，填写 {} 清除。</small></label><label class="field">额外请求参数（JSON 对象）<textarea name="extraBody" class="mono" rows="4" placeholder='例如 {"thinking":{"type":"disabled"}}'>` +
      `${esc(body)}</textarea>` +
      `<small>按所选平台的协议填写；不自动向其他平台发送专属参数。</small></label></div></details><div id="provider-form-error" class="inline-error" role="alert">` +
      `</div><div class="form-actions">${
        existing
          ? `<button class="btn danger" type="button" data-action="delete-provider" data-id="${esc(p.id)}">` +
            `${icon('trash')}删除服务</button>`
          : ''
      }<button class="btn" type="button" data-action="close-modal">` +
      `取消</button><button class="btn primary" type="submit">${icon('save')}保存服务</button>` +
      `</div></form>`,
    { wide: true },
  );
  const f = document.getElementById('provider-form');
  f.elements.model.setAttribute('list', 'provider-model-list');
  document.getElementById('provider-model-choice').onchange = (e) => {
    if (e.target.value) {
      f.elements.model.value = e.target.value;
      modalDirty = true;
    }
  };
  document.getElementById('provider-preset').onchange = (e) => {
    const values = {
      openai: 'https://api.openai.com/v1',
      deepseek: 'https://api.deepseek.com',
      local: 'http://127.0.0.1:1234/v1',
    };
    if (values[e.target.value]) {
      f.elements.baseUrl.value = values[e.target.value];
      if (!f.elements.name.value)
        f.elements.name.value = { openai: 'OpenAI', deepseek: 'DeepSeek', local: '本地服务' }[e.target.value];
      modalDirty = true;
    }
  };
  if (f.elements.clearKey)
    f.elements.clearKey.onchange = () => {
      const clear = f.elements.clearKey.checked;
      if (clear) f.elements.apiKey.value = '';
      f.elements.apiKey.disabled = clear;
    };
  f.onsubmit = (e) => {
    e.preventDefault();
    let data;
    try {
      data = providerFormData(f, existing);
    } catch (err) {
      document.getElementById('provider-form-error').textContent = err.message;
      return;
    }
    busy(f.querySelector('[type=submit]'), async () => {
      await api(existing ? `/api/providers/${encodeURIComponent(p.id)}` : '/api/providers', {
        method: existing ? 'PUT' : 'POST',
        body: data,
      });
      closeModal(true);
      await refreshBootstrap();
      if (state.route === 'ai') renderAi();
      else await render();
      toast('翻译服务已保存');
    });
  };
}
function providerFormData(f, existing = false) {
  const d = new FormData(f),
    data = {
      name: d.get('name').trim(),
      baseUrl: d.get('baseUrl').trim(),
      model: d.get('model').trim(),
      stream: f.elements.stream.checked,
      temperature: d.get('temperature') === '' ? null : Number(d.get('temperature')),
      maxTokens: d.get('maxTokens') === '' ? null : Number(d.get('maxTokens')),
      timeoutSeconds: Number(d.get('timeoutSeconds')),
    };
  const key = d.get('apiKey') || '';
  if (!existing || key) data.apiKey = key;
  if (f.elements.clearKey?.checked) data.clearKey = true;
  for (const [field, label] of [
    ['extraHeaders', '额外请求头'],
    ['extraBody', '额外请求参数'],
  ]) {
    const value = d.get(field).trim();
    if (!value) {
      if (field === 'extraBody') data[field] = {};
      continue;
    }
    let parsed;
    try {
      parsed = JSON.parse(value);
    } catch {
      throw new Error(`${label}必须是有效的 JSON。`);
    }
    if (!parsed || Array.isArray(parsed) || typeof parsed !== 'object') throw new Error(`${label}必须是 JSON 对象。`);
    data[field] = parsed;
  }
  return data;
}
function modelPreviewFormData(f, providerId) {
  const data = {
    baseUrl: f.elements.baseUrl.value.trim(),
    timeoutSeconds: Number(f.elements.timeoutSeconds.value),
    clearKey: !!f.elements.clearKey?.checked,
  };
  if (providerId) data.providerId = providerId;
  const key = f.elements.apiKey.value;
  if (!providerId || key) data.apiKey = key;
  const raw = f.elements.extraHeaders.value.trim();
  if (raw) {
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      throw new Error('额外请求头必须是有效的 JSON。');
    }
    if (!parsed || Array.isArray(parsed) || typeof parsed !== 'object') throw new Error('额外请求头必须是 JSON 对象。');
    data.extraHeaders = parsed;
  }
  return data;
}
function showTranslate() {
  modal(
    '手动试译',
    '发送你输入的文字到当前游戏或全局配置的服务。',
    `<form id="translate-form"><label class="field">游戏上下文<select name="gameId">${gameOptions(state.gameId, '使用全局配置')}</select>` +
      `</label><label class="field">原文<textarea name="text" rows="5" placeholder="输入一段游戏文字…" required></textarea></label>` +
      `<p class="tiny muted">点击「翻译」将发送一次实际 API 请求，并保存翻译记录。</p><div id="translate-result"></div><div class="form-actions">` +
      `<button class="btn" type="button" data-action="close-modal">关闭</button><button class="btn primary" type="submit">` +
      `${icon('send')}翻译</button>` +
      `</div></form>`,
  );
  document.getElementById('translate-form').onsubmit = (e) => {
    e.preventDefault();
    const f = e.target;
    busy(f.querySelector('[type=submit]'), async () => {
      const result = await api('/api/translate', {
        method: 'POST',
        body: { gameId: f.elements.gameId.value || undefined, text: f.elements.text.value },
      });
      document.getElementById('translate-result').innerHTML =
        `<div class="result-box">${esc(result.text)}</div><div class="result-meta">${badge(result.cached ? '缓存命中' : '模型译文', result.cached ? 'green' : 'blue')}<span>` +
        `${result.elapsedMs != null ? `${(result.elapsedMs / 1000).toFixed(2)} 秒` : ''}</span>` +
        `</div>`;
      modalDirty = false;
      await refreshBootstrap();
    });
  };
}
function showTranslationEdit(id) {
  const t = main._translationItems?.find((t) => t.id === id);
  if (!t) return;
  modal(
    '修订译文',
    '保存更新工具服务缓存。游戏内生效需重启；Unity 还需备份并处理 XUnity 译文缓存。',
    `<form id="translation-edit"><label class="field">原文<div class="result-box" style="margin:0">${esc(t.source)}</div>` +
      `</label><label class="field">译文<textarea name="translation" rows="6" required>${esc(t.translation)}</textarea>` +
      `</label><div class="form-actions"><button class="btn" type="button" data-action="close-modal">取消</button><button class="btn primary" type="submit">` +
      `${icon('save')}保存译文</button>` +
      `</div></form>`,
    { wide: true },
  );
  document.getElementById('translation-edit').onsubmit = (e) => {
    e.preventDefault();
    busy(e.target.querySelector('[type=submit]'), async () => {
      await api(`/api/translations/${encodeURIComponent(id)}`, {
        method: 'PUT',
        body: { translation: e.target.elements.translation.value },
      });
      closeModal(true);
      await renderTranslations();
      toast('修订译文已保存');
    });
  };
}
function showTerm(t = {}) {
  modal(
    t.id ? '编辑词条' : '添加词条',
    '固定译法会提供给对应游戏的后续翻译。',
    `<form id="term-form"><label class="field">所属游戏<select name="gameId">${gameOptions(t.id ? t.gameId : state.gameId, '全局词条')}</select>` +
      `</label><div class="field-row"><label class="field">原词<input name="source" value="${esc(t.source)}" required placeholder="原文人名 / 术语">` +
      `</label><label class="field">固定译法<input name="target" value="${esc(t.target)}" required placeholder="希望使用的译名">` +
      `</label></div><label class="field">备注<textarea name="note" rows="3" placeholder="可填写身份、语气或使用场景">${esc(t.note)}</textarea>` +
      `</label><div class="form-actions"><button class="btn" type="button" data-action="close-modal">取消</button><button class="btn primary" type="submit">` +
      `${icon('save')}保存词条</button>` +
      `</div></form>`,
  );
  document.getElementById('term-form').onsubmit = (e) => {
    e.preventDefault();
    const f = e.target;
    busy(f.querySelector('[type=submit]'), async () => {
      await api(t.id ? `/api/glossary/${encodeURIComponent(t.id)}` : '/api/glossary', {
        method: t.id ? 'PUT' : 'POST',
        body: {
          gameId: f.elements.gameId.value || null,
          source: f.elements.source.value.trim(),
          target: f.elements.target.value.trim(),
          note: f.elements.note.value,
        },
      });
      closeModal(true);
      await renderGlossary();
      toast('词条已保存');
    });
  };
}
async function showInstall(id) {
  let plan = await api(`/api/games/${encodeURIComponent(id)}/install-plan`);
  const g = gameById(id),
    m = plan.migration;
  const chosen = m?.available && (!g.font?.mode || g.font.mode === 'auto') ? 'existing' : g.font?.mode || 'auto';
  if (m?.available && chosen !== g.font?.mode)
    plan = await api(`/api/games/${encodeURIComponent(id)}/install-plan?fontMode=${encodeURIComponent(chosen)}`);
  const choices = m?.available
    ? `<label class="field">安装时的字体配置<select id="install-font-mode"><option value="existing" ${chosen === 'existing' ? 'selected' : ''}>` +
      `沿用已有 XUnity 字体配置（推荐）</option><option value="auto" ${chosen === 'auto' ? 'selected' : ''}>` +
      `自动中文字体</option><option value="original" ${chosen === 'original' ? 'selected' : ''}>` +
      `使用游戏原字体（关闭替换）</option>${g.font?.mode === 'custom' ? '<option value="custom" selected>当前自定义字体</option>' : ''}</select>` +
      `<small>沿用会保留原有系统字体、TMP 替换和后备参数；使用游戏原字体会清空这些参数。</small></label>`
    : '';
  modal(
    '检查并安装适配',
    `${esc(g?.name || '游戏')} · ${esc(plan.adapter || '适配组件')}`,
    `<p class="card-description">${esc(plan.description || '安装前会备份受影响文件，并记录安装清单。')}</p>${(plan.warnings || []).map((w) => notice(esc(w), 'warning')).join('')}${migrationMarkup(m)}${choices}${g.legacyCachePath ? notice('安装时复制所选旧缓存：' + esc(g.legacyCachePath)) : ''}<div class="subheading">` +
      `<h2>文件变更</h2><small id="install-file-count">${(plan.files || []).length} 项</small>` +
      `</div><div class="plan-files">${
        (plan.files || []).length
          ? plan.files
              .map(
                (f) =>
                  `<div class="plan-file">` +
                  `<code>${esc(f.path)}</code>` +
                  `<small>${esc(f.action)}</small>` +
                  `</div>`,
              )
              .join('')
          : '当前没有可执行的安装计划。'
      }</div>` +
      `${notice('请先退出游戏。安装后需在游戏中验证取词、中文字体和内嵌效果。')}<div class="form-actions">` +
      `<button class="btn" data-action="close-modal">取消</button><button class="btn primary" data-action="confirm-install" data-id="${esc(id)}" ${plan.supported ? '' : 'disabled'}>` +
      `${icon('download')}备份并安装</button>` +
      `</div>`,
    { wide: true },
  );
  const fontChoice = document.getElementById('install-font-mode');
  if (fontChoice)
    fontChoice.onchange = async () => {
      const button = document.querySelector('[data-action="confirm-install"]');
      button.disabled = true;
      try {
        const next = await api(
          `/api/games/${encodeURIComponent(id)}/install-plan?fontMode=${encodeURIComponent(fontChoice.value)}`,
        );
        if (!fontChoice.isConnected) return;
        document.getElementById('install-file-count').textContent = `${next.files.length} 项`;
        document.querySelector('.plan-files').innerHTML = next.files
          .map((f) => `<div class="plan-file"><code>${esc(f.path)}</code><small>${esc(f.action)}</small></div>`)
          .join('');
        button.disabled = !next.supported;
      } catch (e) {
        errorToast(e);
      }
    };
}
async function showLegacyCache(id) {
  const g = gameById(id),
    m = await api(`/api/games/${encodeURIComponent(id)}/migration`);
  modal(
    '旧译文缓存',
    esc(g.name),
    `${migrationMarkup(m)}<form id="legacy-cache-form"><label class="field">手动选择缓存目录<div class="inline-input">` +
      `<input id="legacy-cache-path" name="path" value="${esc(g.legacyCachePath || '')}" placeholder="原 XUnity 的 TXT / ZIP 译文目录">` +
      `<button type="button" class="btn" data-action="pick-legacy-cache" data-id="${esc(id)}">` +
      `选择</button></div><small>留空取消手动选择。安装时复制到独立目录，原文件保持原样。</small></label><label class="font-clear"><input name="confirmedLanguage" type="checkbox">` +
      `确认所选译文语言为 ${esc(g.targetLanguage || state.settings.targetLanguage)}</label>` +
      `<div class="form-actions"><button class="btn" type="button" data-action="close-modal">取消</button><button class="btn primary" type="submit">` +
      `保存选择</button></div></form>`,
    { wide: true },
  );
  const f = document.getElementById('legacy-cache-form');
  f.onsubmit = (e) => {
    e.preventDefault();
    busy(f.querySelector('[type=submit]'), async () => {
      await api(`/api/games/${encodeURIComponent(id)}/legacy-cache`, {
        method: 'PUT',
        body: { path: f.elements.path.value.trim(), confirmedLanguage: f.elements.confirmedLanguage.checked },
      });
      closeModal(true);
      await refreshBootstrap();
      renderGame();
      toast('旧缓存目录已保存，安装时复制');
    });
  };
}

document.addEventListener('click', async (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  if (button.disabled || state.updateInProgress) return;
  event.stopPropagation();
  const action = button.dataset.action,
    id = button.dataset.id;
  const replacesPage = [
    'refresh-page',
    'library-view',
    'recheck-game',
    'cleanup-game',
    'remove-game',
    'install-game',
    'uninstall-game',
    'game-font',
    'add-provider',
    'edit-provider',
    'select-provider',
    'toggle-translation',
    'resume-game-translation',
    'select-theme',
    'theme-cycle',
  ];
  if (replacesPage.includes(action) && !checkDirty()) return;
  if (action === 'toggle-nav') {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebar-backdrop').classList.toggle('open');
    return;
  }
  if (action === 'close-modal') {
    closeModal();
    return;
  }
  if (action === 'local-update') {
    showLocalUpdate();
    return;
  }
  if (action === 'recover-update') {
    showUpdateRecovery(id, button.dataset.version);
    return;
  }
  if (action === 'pick-update') {
    await busy(button, async () => {
      const result = await api('/api/updates/pick', { method: 'POST' });
      if (result.path && document.getElementById('update-path'))
        document.getElementById('update-path').value = result.path;
    });
    return;
  }
  if (action === 'install-local-update') {
    await busy(button, () => installLocalUpdate(id, button.dataset.restore === 'true'));
    return;
  }
  if (action === 'add-game') {
    showAddGame();
    return;
  }
  if (action === 'game-detail') {
    if (!checkDirty()) return;
    location.hash = `game/${encodeURIComponent(id)}`;
    return;
  }
  if (action === 'library-view') {
    state.view = button.dataset.value;
    localStorage.setItem('libraryView', state.view);
    renderLibrary();
    return;
  }
  if (action === 'add-provider') {
    showProvider();
    return;
  }
  if (action === 'edit-provider') {
    showProvider(providerById(id) || {});
    return;
  }
  if (action === 'translate-test') {
    showTranslate();
    return;
  }
  if (action === 'edit-translation') {
    showTranslationEdit(id);
    return;
  }
  if (action === 'add-term') {
    showTerm();
    return;
  }
  if (action === 'edit-term') {
    showTerm(main._glossaryItems?.find((t) => t.id === id) || {});
    return;
  }
  if (action === 'translation-page') {
    state.translationPage = Number(button.dataset.value);
    await renderTranslations();
    return;
  }
  if (action === 'toggle-log-auto') {
    state.logs.auto = !state.logs.auto;
    await renderLogs();
    return;
  }
  await busy(button, async () => {
    if (action === 'refresh-page') {
      await refreshBootstrap();
      await render();
    } else if (action.startsWith('hook-')) await hookAction(action, id, button);
    else if (action === 'refresh-logs') await renderLogs();
    else if (action === 'player-log') await showPlayerLog(id);
    else if (action === 'pick-player-log') {
      const result = await api(`/api/games/${encodeURIComponent(id)}/player-log/pick`, { method: 'POST' });
      if (result.path && document.getElementById('player-log-path')) {
        document.getElementById('player-log-path').value = result.path;
        modalDirty = true;
      }
    } else if (action === 'export-diagnostics') {
      const query = new URLSearchParams({
        level: state.logs.level || '',
        q: state.logs.q || '',
        source: state.logs.module || '',
        scope: state.logs.scope || '',
      });
      await api(`/api/games/${encodeURIComponent(id)}/diagnostics/export?${query}`, { download: true });
      toast('脱敏游戏诊断已导出');
    } else if (action === 'copy-diagnostics') {
      const report = diagnosticReports[id] || (await api(`/api/games/${encodeURIComponent(id)}/diagnostics`));
      const text = JSON.stringify(report, null, 2);
      try {
        await navigator.clipboard.writeText(text);
        toast('诊断已复制');
      } catch {
        modal(
          '复制诊断',
          '可选中下方文本复制',
          `<textarea class="diagnostic-copy" readonly rows="14">${esc(text)}</textarea><div class="form-actions">` +
            `<button class="btn" data-action="close-modal">关闭</button></div>`,
          { wide: true },
        );
        document.querySelector('.diagnostic-copy').select();
      }
    } else if (action === 'refresh-runtime') await refreshRuntime(id, true);
    else if (action === 'runtime-advice') await showRuntimeAdvice(id);
    else if (action === 'refresh-script-compat') await refreshScriptCompatibility(id);
    else if (action === 'pick-game') {
      const result = await api('/api/games/pick', { method: 'POST' });
      if (result?.path) {
        document.getElementById('game-path').value = result.path;
        modalDirty = true;
      }
    } else if (action === 'game-font') await showGameFont(id);
    else if (action === 'legacy-cache') await showLegacyCache(id);
    else if (action === 'pick-legacy-cache') {
      const result = await api(`/api/games/${encodeURIComponent(id)}/legacy-cache/pick`, { method: 'POST' });
      if (result.path && document.getElementById('legacy-cache-path')) {
        document.getElementById('legacy-cache-path').value = result.path;
        modalDirty = true;
      }
    } else if (action === 'inspect-font') {
      const f = document.getElementById('game-font-form'),
        path = f.elements.filePath.value.trim();
      if (!path) {
        toast('先选择需要检查的 TMP 字体包', 'info');
        return;
      }
      const result = await api(`/api/games/${encodeURIComponent(id)}/font/inspect`, {
        method: 'POST',
        body: { path, family: f.elements.family.value.trim() },
      });
      if (document.getElementById('font-inspection')) {
        document.getElementById('font-inspection').innerHTML = tmpReportMarkup(result);
        document.querySelector('#font-inspection details').open = true;
      }
    } else if (action === 'pick-font') {
      const result = await api(`/api/games/${encodeURIComponent(id)}/font/pick`, { method: 'POST' });
      if (result?.path && document.getElementById('font-file-path')) {
        document.getElementById('font-file-path').value = result.path;
        modalDirty = true;
      }
    } else if (action === 'inspect-game') {
      const path = document.getElementById('game-path').value.trim();
      if (!path) {
        toast('先选择游戏启动程序', 'info');
        return;
      }
      const result = await api('/api/games/inspect', { method: 'POST', body: { path } });
      document.getElementById('game-detection').innerHTML =
        `<div class="detection-result"><strong>${esc(result.name || '检测结果')}</strong> ${badge(result.engine || '未知引擎', 'blue')} ${badge(result.architecture || '架构未知')}<p>` +
        `${esc(typeof result.detectionNotes === 'string' ? result.detectionNotes : JSON.stringify(result.detectionNotes || ''))}</p>` +
        `<p>${esc(capabilityLabel(result))} · ${(result.warnings || []).map(esc).join('；')}</p>` +
        `</div>`;
    } else if (action === 'launch-game') {
      await api(`/api/games/${encodeURIComponent(id)}/launch`, { method: 'POST' });
      await refreshRuntime(id, true);
      toast('已请求启动游戏，可在运行诊断中查看取词进度');
    } else if (action === 'recheck-game') {
      await api(`/api/games/${encodeURIComponent(id)}/recheck`, { method: 'POST' });
      await refreshBootstrap();
      renderGame();
      toast('检测结果已更新');
    } else if (action === 'remove-game') {
      const g = gameById(id);
      if (
        !confirm(
          `从游戏库移除「${g?.name || '此游戏'}」？\n只移除游戏库记录，不会删除游戏文件、存档或保留的译文。\n如已安装本工具适配，请先在游戏详情卸载或恢复。`,
        )
      )
        return;
      await api(`/api/games/${encodeURIComponent(id)}`, { method: 'DELETE' });
      await refreshBootstrap();
      if (state.route === 'library') renderLibrary();
      else location.hash = 'library';
      toast('已从游戏库移除');
    } else if (action === 'cleanup-game') await showComponentCleanup(id);
    else if (action === 'install-game') await showInstall(id);
    else if (action === 'confirm-install') {
      const fontMode = document.getElementById('install-font-mode')?.value;
      await api(`/api/games/${encodeURIComponent(id)}/install`, {
        method: 'POST',
        body: fontMode ? { fontMode } : undefined,
      });
      closeModal(true);
      await refreshBootstrap();
      renderGame();
      toast('适配组件已安装，请在游戏中验证效果');
    } else if (action === 'uninstall-game') {
      if (
        !confirm('先退出游戏，再卸载适配。\n工具将按安装清单恢复备份；遇到被其他程序修改的文件会提示冲突。是否继续？')
      )
        return;
      await api(`/api/games/${encodeURIComponent(id)}/uninstall`, { method: 'POST' });
      await refreshBootstrap();
      renderGame();
      toast('适配组件已卸载，恢复结果可查看日志');
    } else if (action === 'select-provider') await saveSettings({ providerId: id }, '当前翻译服务已切换');
    else if (action === 'test-provider') {
      const p = providerById(id);
      if (!confirm(`测试「${p?.name || '此服务'}」将发送一次实际翻译请求，可能产生 API 费用。继续？`)) return;
      const result = await api(`/api/providers/${encodeURIComponent(id)}/test`, { method: 'POST', body: {} });
      modal(
        '连接测试结果',
        esc(p?.name || '翻译服务'),
        `${notice('请求已完成。以返回译文确认实际翻译能力。')}<div class="result-box">${esc(result.text || result.translation || result.message || '服务请求成功')}</div>` +
          `${
            result.elapsedMs != null
              ? `<p class="result-meta">` + `耗时 ${(result.elapsedMs / 1000).toFixed(2)} 秒</p>`
              : ''
          }<div class="form-actions">` +
          `<button class="btn primary" data-action="close-modal">完成</button></div>`,
      );
      await refreshBootstrap();
    } else if (action === 'provider-models') {
      const f = document.getElementById('provider-form');
      if (!f.elements.baseUrl.reportValidity() || !f.elements.timeoutSeconds.reportValidity()) return;
      const preview = modelPreviewFormData(f, id);
      document.getElementById('provider-form-error').textContent = '';
      const models = await api('/api/providers/models/preview', { method: 'POST', body: preview });
      if (!f.isConnected) return;
      const items = Array.isArray(models) ? models : models?.models || models?.data || models?.items || [];
      const ids = [
        ...new Set(items.map((m) => (typeof m === 'string' ? m : m.id)).filter((v) => typeof v === 'string' && v)),
      ];
      document.getElementById('provider-model-list').innerHTML = ids
        .map((v) => `<option value="${esc(v)}"></option>`)
        .join('');
      const choice = document.getElementById('provider-model-choice');
      choice.hidden = !ids.length;
      choice.innerHTML =
        '<option value="">从返回的模型中选择…</option>' +
        ids.map((v) => `<option value="${esc(v)}">${esc(v)}</option>`).join('');
      if (ids.length && !f.elements.model.value.trim()) {
        f.elements.model.value = ids[0];
        modalDirty = true;
      }
      choice.value = ids.includes(f.elements.model.value) ? f.elements.model.value : '';
      toast(
        ids.length ? `已获取 ${ids.length} 个模型，可下拉选择或手动填写` : '服务没有返回模型列表，仍可手动填写',
        'info',
      );
    } else if (action === 'delete-provider') {
      const p = providerById(id);
      if (!confirm(`删除服务「${p?.name || '此服务'}」及其本机密钥？使用该配置的游戏需要重新选择服务。`)) return;
      await api(`/api/providers/${encodeURIComponent(id)}`, { method: 'DELETE' });
      closeModal(true);
      await refreshBootstrap();
      await render();
      toast('翻译服务已删除');
    } else if (action === 'toggle-translation')
      await saveSettings(
        { enabled: state.settings.enabled === false },
        state.settings.enabled === false ? '翻译已启用' : '翻译已暂停',
      );
    else if (action === 'resume-game-translation') {
      const global = button.dataset.scope === 'global';
      await api(global ? '/api/settings' : `/api/games/${encodeURIComponent(id)}`, {
        method: 'PUT',
        body: { enabled: true },
      });
      await refreshBootstrap();
      renderGame();
      toast(global ? '全局翻译已启用，请重新启动游戏' : '此游戏翻译已启用，请重新启动游戏');
    } else if (action === 'delete-translation') {
      if (
        !confirm(
          '删除这条工具服务缓存？\nRen’Py / RPG Maker 需重启游戏；Unity 还需备份并处理 XUnity 译文缓存。刷新游戏侧缓存后，再验证是否重新翻译。',
        )
      )
        return;
      await api(`/api/translations/${encodeURIComponent(id)}`, { method: 'DELETE' });
      await renderTranslations();
      toast('翻译缓存已删除');
    } else if (action === 'delete-term') {
      if (!confirm('删除这个词条？已有翻译缓存保持原样。')) return;
      await api(`/api/glossary/${encodeURIComponent(id)}`, { method: 'DELETE' });
      await renderGlossary();
      toast('词条已删除');
    } else if (action === 'export-logs') {
      await api('/api/logs/export', { download: true });
      toast('日志已导出');
    } else if (action === 'export-data') {
      await api('/api/data/export', { method: 'POST', download: true });
      toast('不含凭据的数据备份已导出');
    } else if (action === 'open-folder') {
      await api('/api/folders/open', { method: 'POST', body: { kind: button.dataset.kind, gameId: id || undefined } });
      toast('已打开目录');
    } else if (action === 'select-theme') {
      await saveSettings({ theme: button.dataset.value }, '主题已切换');
    } else if (action === 'theme-cycle') {
      const choices = ['system', 'light', 'dark'];
      await saveSettings(
        { theme: choices[(choices.indexOf(state.settings.theme) + 1) % choices.length] },
        '主题已切换',
      );
    }
  });
});
async function showComponentCleanup(id) {
  const game = gameById(id),
    preview = await api(`/api/games/${encodeURIComponent(id)}/cleanup`);
  const labels = {
    remove: '移除组件',
    restore: '恢复原文件',
    keep: '保留',
    original: '保留原文件',
    absent: '已不存在',
    'delete-backup': '可选删除备份',
  };
  const visible = preview.items.filter((item) => item.action !== 'absent' && item.action !== 'original');
  const rows = visible
    .slice(0, 200)
    .map(
      (item) =>
        `<tr><td><span class="cleanup-path">${esc(item.area === 'backup' ? '工具备份 / ' + item.path : item.path)}</span>` +
        `</td><td>${esc(labels[item.action] || '保留')}</td>` +
        `<td>${esc(item.reason)}</td>` +
        `</tr>`,
    )
    .join('');
  modal(
    '清理残留',
    esc(game?.name || '此游戏'),
    `${notice(esc(preview.message), preview.activeInstallation || preview.conflictCount ? 'warning' : 'info')}<p class="section-gap tiny muted">` +
      `可移除 ${number(preview.removeCount)} 个组件 · 可恢复 ${number(preview.restoreCount)} 个原文件 · ${number(preview.backupCount)} 个备份 · ${number(preview.conflictCount)} 个待处理项${preview.resetRecord ? ' · 修正已失效的安装记录' : ''}</p>` +
      `${
        rows
          ? `<div class="table-wrap cleanup-table section-gap">` +
            `<table><thead><tr><th>文件</th><th>处理</th><th>原因</th></tr></thead><tbody>${rows}</tbody>` +
            `</table></div>${visible.length > 200 ? '<p class="tiny muted section-gap">先显示前 200 项，确认时按本次完整扫描范围处理。</p>' : ''}`
          : ''
      }<form id="component-cleanup-form">` +
      `<label class="font-clear section-gap"><input type="checkbox" name="deleteBackups" ${!preview.canDeleteBackups ? 'disabled' : ''}>` +
      `同时删除已完成恢复的原始文件备份（不可撤销）</label><p class="tiny muted section-gap">默认保留备份。未归属的组件、游戏文件、存档、译文、导入字体和运行期归档保留。清理前请退出游戏。</p>` +
      `<div class="form-actions"><button class="btn" type="button" data-action="close-modal">取消</button><button class="btn" type="button" data-action="cleanup-game" data-id="${esc(id)}">` +
      `重新扫描</button><button class="btn primary" type="submit" ${!preview.canClean ? 'disabled' : ''}>` +
      `确认清理</button></div></form>`,
    { wide: true },
  );
  const form = document.getElementById('component-cleanup-form');
  const updateCleanupChoice = () => {
    modalDirty = false;
    form.querySelector('[type=submit]').disabled =
      !preview.canClean ||
      (!preview.resetRecord &&
        preview.removeCount + preview.restoreCount === 0 &&
        !form.elements.deleteBackups.checked);
  };
  form.addEventListener('change', updateCleanupChoice);
  updateCleanupChoice();
  form.onsubmit = (event) => {
    event.preventDefault();
    const deleteBackups = form.elements.deleteBackups.checked;
    if (deleteBackups && !confirm('删除本次扫描列出的原始文件备份后无法撤销。确认继续？')) return;
    busy(form.querySelector('[type=submit]'), async () => {
      const result = await api(`/api/games/${encodeURIComponent(id)}/cleanup`, {
        method: 'POST',
        body: { fingerprint: preview.fingerprint, deleteBackups, confirmed: true },
      });
      closeModal(true);
      await refreshBootstrap();
      renderGame();
      const clean = result.cleanup;
      toast(
        `已移除 ${clean.removed} 个组件、恢复 ${clean.restored} 个原文件、删除 ${clean.backupsDeleted} 个备份${clean.remainingConflicts ? '；部分文件已保留，请重新扫描查看' : ''}`,
        clean.remainingConflicts ? 'info' : 'success',
      );
    });
  };
}
function checkDirty() {
  if (state.updateInProgress) return false;
  if (state.dirty && !confirm('当前设置尚未保存，确定离开页面吗？')) return false;
  state.dirty = false;
  return true;
}
document.addEventListener('click', (event) => {
  const link = event.target.closest('a[href^="#"]');
  if (link && !checkDirty()) event.preventDefault();
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    if (document.getElementById('modal-root').childElementCount) closeModal();
    else {
      document.getElementById('sidebar').classList.remove('open');
      document.getElementById('sidebar-backdrop').classList.remove('open');
    }
  }
  if (event.key === 'Enter' && event.target.matches('.game-card,.game-row')) {
    event.preventDefault();
    event.target.click();
  }
  if (event.key === 'Tab' && document.getElementById('modal-root').childElementCount) {
    const dialog = document.querySelector('.modal');
    const focusables = [...dialog.querySelectorAll('button,input,select,textarea,a[href]')].filter(
        (el) => !el.disabled && el.offsetParent !== null,
      ),
      first = focusables[0],
      last = focusables[focusables.length - 1];
    if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog)) {
      event.preventDefault();
      last?.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first?.focus();
    }
  }
});
document.getElementById('sidebar-backdrop').onclick = () => {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebar-backdrop').classList.remove('open');
};
window.addEventListener('hashchange', () => {
  if (!checkDirty()) {
    history.replaceState(null, '', renderedHash || '#library');
    return;
  }
  renderedHash = location.hash;
  state.translationPage = 1;
  render();
});
window.addEventListener('beforeunload', (e) => {
  if (state.dirty || modalDirty) {
    e.preventDefault();
    e.returnValue = '';
  }
});
let dragDepth = 0;
document.addEventListener('dragenter', (e) => {
  if (e.dataTransfer?.types.includes('Files')) {
    e.preventDefault();
    dragDepth++;
    document.body.classList.add('drop-active');
  }
});
document.addEventListener('dragleave', () => {
  if (--dragDepth <= 0) {
    dragDepth = 0;
    document.body.classList.remove('drop-active');
  }
});
document.addEventListener('dragover', (e) => {
  if (e.dataTransfer?.types.includes('Files')) e.preventDefault();
});
document.addEventListener('drop', (e) => {
  if (!e.dataTransfer?.files.length) return;
  e.preventDefault();
  dragDepth = 0;
  document.body.classList.remove('drop-active');
  const file = e.dataTransfer.files[0];
  if (file.path) {
    showAddGame(file.path);
  } else {
    showAddGame();
    toast('浏览器无法读取拖入文件的完整路径，请点击「选择」或粘贴路径', 'info');
  }
});
async function start() {
  try {
    const response = await fetch('/api/session', { credentials: 'same-origin', cache: 'no-store' });
    if (!response.ok) throw new Error('无法连接本机服务');
    const session = await response.json();
    state.token = session.token;
    await refreshBootstrap();
    await render();
  } catch (e) {
    main.innerHTML = `${pageHead('打开工作空间', '连接本机游戏翻译服务。')}${empty('本机服务连接失败', `${esc(e.message)}。请保持启动程序运行后刷新页面。`, '<button class="btn primary" onclick="location.reload()">重新连接</button>', 'warning')}`;
  }
}
start();
